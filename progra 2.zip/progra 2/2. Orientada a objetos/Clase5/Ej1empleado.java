 import java.util.Scanner;
 public class Ej1empleado{

   public static void main (String[]args){
    
   Scanner in = new Scanner (System.in); 
   System.out.println("Ingrese el nombre del empleado: ");
   String nombre = in.next();
   in.nextLine();
   System.out.println("Ingrese el sueldo: ");
   double sueldo = in.nextDouble();
   System.out.println("Ingrese el dni ");
   int dni = in.nextInt();
   System.out.println("Ingrese la edad: ");
   int edad = in.nextInt();
   System.out.println("Ingrese la cant de partidos: ");
   int cantPartidos = in.nextInt();
   System.out.println("Ingrese la cant de goles: ");
   int cantGoles = in.nextInt();
   
   Empleado j = new Jugador (cantGoles,cantPartidos,nombre,dni,edad,sueldo);
   
   System.out.println("Ingrese el nombre del entrenador: ");
   nombre = in.next();
   in.nextLine();
   System.out.println("Ingrese el sueldo: ");
   sueldo = in.nextDouble();
   System.out.println("Ingrese el dni ");
   dni = in.nextInt();
   System.out.println("Ingrese la edad: ");
   edad = in.nextInt();
   System.out.println("Ingrese la cant de campeonatos: ");
   int cantCampeonatos = in.nextInt();
   
   Empleado e = new Entrenador (cantCampeonatos,nombre,dni,edad,sueldo);
   System.out.println ("**********************************************");
       System.out.println ("Ingrese 1- Si es un Jugador");
       System.out.println ("Ingrese 2- Si es un Entrenador");
       System.out.println ("Ingrese 0 - para finalizar");
       System.out.println ("**********************************************");
       int opcion = in.nextInt();
       while (opcion != 0){
           switch (opcion){
           case 1:{
               System.out.println(j.representacion());
           }
           break;
           case 2:{
               System.out.println (e.representacion());
           }    
           break;
           default:
               System.out.println ("La opcion ingresada es incorrecta"); 
        }
         opcion = in.nextInt();
          System.out.println ("**********************************************");
          System.out.println ("Ingrese 1- Si es un Jugador");
          System.out.println ("Ingrese 2- Si es un Entrenador");
          System.out.println ("Ingrese 0 - para finalizar");
          System.out.println ("**********************************************");
    }
}
}