
/**
 1 -  Queremos representar la información de empleados de un club: jugadores y entrenadores. 
Cualquier empleado se caracteriza por su nombre, DNI, edad y sueldo básico. 
Los jugadores son empleados que se caracterizan por el número de partidos jugados y el número de goles anotados.
Los entrenadores son empleados  que se caracterizan por la cantidad de campeonatos ganados.

A- Implemente la jerarquía de clases, con los atributos de cada clase y métodos para obtener/modificar el valor de los mismos. 
B- Implemente constructores para los jugadores y entrenadores, que reciban toda la información necesaria para inicializar el objeto en cuestión. 
C- Cualquier empleado (jugador / entrenador) debe saber responder al mensaje calcularSueldoACobrar (que calcula y devuelve el sueldo a cobrar) 
pero de manera diferente:
       Para los jugadores: el sueldo a cobrar es el sueldo básico y si el promedio de goles por partido es superior a 0,5 se adiciona un plus 
        de otro sueldo básico. 
       Para los entrenadores: el sueldo a cobrar es el sueldo básico al cual se le adiciona un plus por campeonatos ganados 
       (5000$ si ha ganado entre 1 y 4 campeonatos;  $30.000 si ha ganado entre 5 y 10 campeonatos; 50.000$ si ha ganado más de 10 campeonatos). 

 */
public abstract class Empleado {
    private String nombre;
    private double sueldo;
    private int edad; 
    private int dni;
    public Empleado (String nombre, int dni, int edad, double sueldo){
        this.setNombre(nombre);
        this.setSueldo(sueldo);
        this.setEdad(edad); 
        this.setDNI(dni);
    }
    
    public Empleado(){
     
    }

    public double getSueldo() {
        return sueldo;
    }
    
    public int getDNI() {
        return dni;
    }
    
    public int getEdad() {
        return edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    public void setDNI(int dni) {
        this.dni = dni;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
    public String representacion(){
     
       return ("Nombre:" + nombre + " Dni: "+dni+ " edad: "+edad+" Sueldo: "+ calcularSueldoACobrar ()) ;   
    }
    abstract double calcularSueldoACobrar ();
        
           
    }    
    

