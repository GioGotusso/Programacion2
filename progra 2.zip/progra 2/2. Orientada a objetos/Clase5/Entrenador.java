

public class Entrenador extends Empleado{
   private int cantGanados;
   
  /* Añadido: tema constructores (1er constructor) */ 
  public Entrenador( int cantGanados,String nombre,int dni,int edad, double sueldo ){
      super(nombre,dni,edad,sueldo);
      this.cantGanados = cantGanados;
    
  } 
  
    /* Añadido: tema constructores (2do constructor) */  
   public Entrenador(){

   } 
   
   
  public int getcantGanados(){
       return cantGanados;       
  }
  public void setcantGanados(int cantGanados)
  {
       this.cantGanados = cantGanados;
  }
  
  public double calcularSueldoACobrar(){
      double sueldoACobrar=0;
        if (cantGanados >= 1 && cantGanados<=4)
            sueldoACobrar=super.getSueldo()+5000;
        else if (cantGanados >= 5 && cantGanados <= 10)
            sueldoACobrar=super.getSueldo()+10000;
            else if (cantGanados > 10)
                sueldoACobrar=super.getSueldo()+50000;
        return sueldoACobrar;        
  }
  
  
  public String representacion(){
     String aux;
     aux= ("Cantidad de torneos ganados" +cantGanados+ super.representacion()); 
     return aux;
  }
  

}


