public class Jugador extends Empleado{
   private int cantJugados;
   private int cantGoles;
  /* Añadido: tema constructores (1er constructor) */ 
  public Jugador( int cantGoles, int cantJugados,String nombre,int dni,int edad, double sueldo ){
      super(nombre,dni,edad,sueldo);
      this.cantJugados = cantJugados;
      this.cantGoles = cantGoles;
  } 
  
    /* Añadido: tema constructores (2do constructor) */  
   public Jugador(){

   } 
      
  public int getcantJugados(){
       return cantJugados;       
  }
  public void setcantJugados(int cantJugados)
  {
       this.cantJugados = cantJugados;
  }
  
  public int getcantGoles(){
       return cantGoles;       
  }
  public void setcantGoles(int cantJugados)
  {
       this.cantGoles = cantGoles;
  }
  /* 	Para los jugadores: el sueldo a cobrar es el sueldo básico y si el promedio de goles por partido es superior a 0,5 
   * se adiciona un plus de otro sueldo básico. */
  public double calcularSueldoACobrar(){
        double prom, plus=0;
        prom=(cantGoles/cantJugados);
        if (prom > 0.5){
            plus = super.getSueldo()*2;
        }
        else
           plus = super.getSueldo();
        return plus;        
  }
  
  
  public String representacion(){
     String aux = ("Cantidad partidos jugados: "+cantJugados+ " Cantidad de goles: "+cantGoles+ super.representacion());
     return aux;
  }
  

}