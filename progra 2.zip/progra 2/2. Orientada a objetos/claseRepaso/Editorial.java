
/**
Una editorial universitaria, necesita registrar la información correspondiente a los ejemplares que publicó y se publicarán. 
Cada Ejemplar posee un código identificatorio, cantidad de páginas, un resumen, año de publicación (si aún no fue publicado este valor es cero)
 y la información del responsable a cargo de la edición. Para el responsable se registra su DNI, nombre y apellido. 
*/
public class Editorial
{
    //variables de instancia
    private int codigo;
    private int cantPaginas;
    private String resumen;
    private int año;

    //  Constructor de la clase Editorial
    public Editorial(int codigo, int cantPaginas, String resumen, int año)
    {
        this.codigo=codigo;
        this.cantPaginas=cantPaginas;
        this.resumen=resumen;
        this.año=año;
    }
    //constructor vacio
    public Editorial() {
    }
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
d