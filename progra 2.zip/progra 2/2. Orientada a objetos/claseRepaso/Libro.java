
/**
 -	Libro, que también tiene asociado un título, la cantidad de capítulos del mismo y si es o no una edición de bolsillo.
 */
public class Libro
{
    // instance variables - replace the example below with your own
    private String titulo;
    private int cantCapitulos;
    private boolean esEdBolsillo;
    public Libro(String titulo, int cantCapitulos, boolean esEdBolsillo)
    {
        this.titulo=titulo;
        this.cantCapitulos=cantCapitulos;
        this.esEdBolsillo= esEdBolsillo;
    }
    
    public Libro()
    {
    }
    
    public String getTitulo(){
        return titulo;
    
   }
   public int getCantCapitulos(){
        return cantCapitulos;
    
   }
   
   public boolean getEsEdBolsillo(){
        return esEdBolsillo;
    
   }
   
   public void setTitulo(String titulo){
      this.titulo=titulo;
    } 
    
    public void setCantCapitulos(int cantCapitulos ){
      this.cantCapitulos=cantCapitulos;
    }
    
    public void setEsEdBolsillo(boolean
    esEdBolsillo){
      this.esEdBolsillo=esEdBolsillo;
    }
}
