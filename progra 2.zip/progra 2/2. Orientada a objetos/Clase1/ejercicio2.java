/*
 * Escriba un programa para restringir la entrada de autos al centro de la ciudad: sólo pasarán aquellos con patente par. Para ello se leen 
 * números de patentes, por cada una debe informar en consola si el auto tiene o no permitido el paso.  La lectura
 * finaliza cuando se ingresa la patente 0. Al finalizar, informar el porcentaje de autos que ingresaron respecto al total de autos. 
 */
import java.util.Scanner; 
public class ejercicio2
{
    public static void main(String[] args)
    {Scanner in = new Scanner(System.in);      
        System.out.print("Ingrese la patente: ");
        int patente = in.nextInt();
        while (patente != 0)
        { if (patente % 2 == 0 )
           System.out.println("Tiene permitido el paso");
         else 
             System.out.println("No tiene permitido el paso");
         System.out.print("Ingrese la patente: ");
         patente = in.nextInt();
        }        
    }
}
// instance variables - replace the example below with your own
    

