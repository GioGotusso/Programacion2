
/**
 Escriba un programa que imprima en consola el factorial de todos los números entre 1 y 9.
 ¿Qué modificación debe hacer para imprimir el factorial de los números impares solamente?
 */
import java.util.Scanner; 
public class ejercicio4
{   public static void main(String[] args)
    {
          Scanner in = new Scanner(System.in);
          System.out.println("Ingrese un numero: ");
          int num = in.nextInt();
          while (num>0 && num<=9)
          {
           int i ; int fact=1;   
           for (i=1; i<=num ; i++)
              fact = fact * i;
            System.out.println(num+"! = "+fact);
           System.out.println("Ingrese un numero: ");
           num = in.nextInt();
          }
          
          System.out.println("Ingrese un numero: ");
          num = in.nextInt();
          System.out.println("---------------------------");
          while (num % 2 != 0)
           {
           int i ; int fact=1;   
           for (i=1; i<=num ; i++)
              fact = fact * i;
            System.out.println(num+"! = "+fact);
           System.out.println("Ingrese un numero: ");
           num = in.nextInt();
          }
    }
}