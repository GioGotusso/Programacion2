/*
 *1 - Escriba un programa que lea desde teclado 3 valores double. Determine si a partir de ellos se forma un triángulo 
 *válido y en ese caso muestre en consola el perímetro del mismo. 
NOTA: Un triángulo es válido si se cumplen las siguientes tres condiciones: 
(a < b + c) ,  (b < a + c), (c < a + b), donde a,b,c son los lados.   
 */
import java.util.Scanner; 
public class ejercicio1
{
    public static void main(String[]args)
    {           
        Scanner in = new Scanner(System.in);       
        System.out.print("ingrese 3 valores : ");
        double perimetro;
        double lado1 = in.nextDouble(),lado2 = in.nextDouble(),lado3 = in.nextDouble();
        in.close();   
        if (lado1 < lado2 + lado3 && lado2 < lado1 + lado3 && lado3 < lado1 + lado2 )
           {  perimetro = lado1+lado2+lado3;
             System.out.print("El perimetro del triangulo es: "+ perimetro); 
            }
        else
           System.out.print("Los valores no son validos para crear un triangulo");
    }
}
    
            
          

           
           
           
           
           
           
           
          