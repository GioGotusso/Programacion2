
/**Escriba un programa que imprima en consola el factorial de un número N
 *(ingresado por teclado, N > 0).  Ejemplo: para N=5 debería imprimir 5! = 120
 * 
 */
import java.util.Scanner; 
public class ejercicio3
    {public static void main(String[] args)
        {
          Scanner in = new Scanner(System.in);
          System.out.println("Ingrese un numero: ");
          int num = in.nextInt();
          int i ; int fact=1;
          if (num > 0)
           for (i=1; i<=num ; i++)
              fact = fact * i;
           
            System.out.print(num+"! = "+fact);
          }
        }     
    