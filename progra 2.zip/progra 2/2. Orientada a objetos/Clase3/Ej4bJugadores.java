
/**
B- Implemente un programa para que se lean desde teclado y almacenen en un vector a lo sumo 50 jugadores.
 Luego de almacenar la información, agregue un método que devuelva la cantidad de jugadores con más de 100 partidos jugados. 
 */
import java.util.Scanner;
public class Ej4bJugadores{
    public static void main (String[]args){
        Scanner in = new Scanner (System.in);
        Jugadores [] vector = new Jugadores [5]; //50
        int j;
        for (j=0; j<5; j++)
        {
            System.out.println("Ingrese el nombre del jugador:");
            String nombre = in.next();
            in.nextLine();
            System.out.println("Ingrese el DNI del jugador:");
            int dni = in.nextInt();
            System.out.println("Ingrese la edad del jugador:");
            int edad = in.nextInt();
            System.out.println("Ingrese la cantidad de partidos jugados del jugador:");
            int cantP = in.nextInt();
            System.out.println("Ingrese la cantidad de goles del jugador:");
            int cantG = in.nextInt();
            vector [j] = new Jugadores (nombre, dni, edad, cantP, cantG);
        }
        in.close();
        System.out.println ("La cantidad de jugadores con mas de 100 partidos jugados es: "+getMas100Partidos(vector));
        
    }
    public static int getMas100Partidos ( Jugadores vector[])
    {
        int i, cant=0;
        for (i=0; i<5; i++)
        {
            if (vector[i].getPartidos()> 100){
                cant++;
            }
        }
        return cant;    
    }
}
