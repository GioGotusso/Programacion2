
/**
 B- Realizar un programa principal que instancie un entrenador, cargándole datos leídos desde teclado. 
 Pruebe el correcto funcionamiento de cada método implementado. 
 */
 import java.util.Scanner;
 public class Ej3bEntrenador{

   public static void main (String[]args){
    
   Scanner in = new Scanner (System.in); 
   System.out.println("Ingrese el nombre del entrenador: ");
   String nombre = in.nextLine();
   System.out.println("Ingrese el sueldo: ");
   double sueldo = in.nextDouble();
   System.out.println("Ingrese la cantidad de partidos ganados: ");
   int cant = in.nextInt();
   Entrenador e = new Entrenador (nombre,sueldo,cant);
   System.out.println(e.calcularSueldoACobrar());
}
}
