
/**
Un hipermercado necesita gestionar sus productos y su stock. De cada producto se debe registrar: 
código y nombre del producto, descripción, marca y unidades disponibles.  

Se pide:    
a. Crear la clase Producto con todos sus atributos, getters y setters.    

 */
public class Hipermercado
{
    private int codigo;
    private String nombre;
    private String descripcion;
    private String marca;
    private int cantDisponible;
    
    public Hipermercado (int unCodigo, String unNombre, String unaDescripcion,String unaMarca, int unaCantidad)
    { 
        codigo= unCodigo;
        nombre= unNombre;
        descripcion= unaDescripcion;
        marca= unaMarca;
        cantDisponible = unaCantidad;
    }
   
    public Hipermercado()
    { 
    }
    public int getCodigo(){
        return codigo;
    }
    public String getNombre(){
        return nombre;
    }
    public String getDescripcion(){
        return descripcion;
    }
    public String getMarca(){
        return marca;
    }
    public int getCantDisponible(){
        return cantDisponible;
    }
    public void setCodigo (int unCodigo){
       codigo=unCodigo;
    }
    public void setNombre (String unNombre){
       nombre=unNombre;
    }
    public void setDescripcion (String unaDescripcion){
       descripcion=unaDescripcion;
    }
    public void setMarca (String unaMarca){
       marca=unaMarca;
    }
    public void setCantDisponible(int unaCantidad){
        cantDisponible=unaCantidad;
    }
    public String toString(){
        String aux; 
        aux = "Producto numero: " + codigo + ", nombre: " + nombre + " marca: " + marca + " descripcion: " +descripcion+" Catidad en Stock: "+cantDisponible;
        return aux;
    }
    
}