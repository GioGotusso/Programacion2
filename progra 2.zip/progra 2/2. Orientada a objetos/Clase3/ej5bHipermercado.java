
/**
b. Realizar un programa con un menú de opciones que permita ingresar productos y su stock y que muestre su contenido. 
 */
import java.util.Scanner;
public class ej5bHipermercado
{
   public static void main (String[]args){
    
       Scanner in = new Scanner (System.in);
       System.out.println ("**********************************************");
       System.out.println ("Ingrese la opcion que desea realizar:");
       System.out.println ("Ingrese 1- para ingresar un nuevo producto");
       System.out.println ("Ingrese 2- para ingresar el Stock");
       System.out.println ("Ingrese 3 - para mostrar el contenido");
       System.out.println ("Ingrese 0 - para finalizar compra");
       System.out.println ("**********************************************");
       int opcion = in.nextInt();
       Hipermercado h = new Hipermercado();
       while (opcion != 0){
           switch (opcion){
           case 1:{
               System.out.println("Ingrese el nombre del producto: ");
               String nombre = in.next();
               in.nextLine();
               System.out.println("Ingrese el codigo del producto: ");
               int codigo = in.nextInt();
               System.out.println("Ingrese la descripcion del producto: ");
               String descripcion = in.next();
               in.nextLine();
               System.out.println("Ingrese la marca del producto: ");
               String marca = in.next();
               in.nextLine(); 
               h.setCodigo(codigo);
               h.setDescripcion(descripcion);
               h.setMarca(marca);
               h.setNombre(nombre);
           }
           break;
           case 2:{
               System.out.println ("Ingrese el Stock:");
               int stock = in.nextInt();
               h.setCantDisponible(stock);
           }    
           break;
           case 3:{ 
               System.out.println(h.toString());
           }
           break;
           default:
               System.out.println ("La opcion ingresada es incorrecta"); 
        }
    
    System.out.println ("**********************************************");
       System.out.println ("Ingrese la opcion que desea realizar:");
       System.out.println ("Ingrese 1- para ingresar un nuevo producto");
       System.out.println ("Ingrese 2- para ingresar el Stock");
       System.out.println ("Ingrese 3 - para mostrar el contenido");
       System.out.println ("Ingrese 0 - para finalizar compra");
       System.out.println ("**********************************************");
       opcion = in.nextInt();
    }
}
}
