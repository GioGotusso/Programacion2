
/**
 1- A- Definir una clase para representar triángulos. Un triángulo se caracteriza por el tamaño de sus 3 lados (double), 
 el color de relleno (String) y el color de línea (String). 
El triángulo debe saber: 
   Devolver/modificar el valor de cada uno de sus atributos (métodos get# y set#) 
   Calcular el área y devolverla (método calcularArea)
   Calcular el perímetro y devolverlo (método calcularPerimetro)
 */
public class Triangulo
{
    private double lado1;
    private double lado2;
    private double lado3;
    private String colorR;
    private String colorL;
                                                                                     
                                                                                      /** Constructor for objects of class Triangulo*/
    public Triangulo(double l1,double l2,double l3,String cR,String cL)
    {
        // initialise instance variables
        lado1 = l1;
        lado2 = l2;
        lado3 = l3;
        colorR = cR;
        colorL = cL;
    }
    public Triangulo(){}
    

    public double getLado1(){
           return lado1;
    }
    public double getLado2(){
           return lado2;
    }
    public double getLado3(){
           return lado3;
    }
    public String getColorR(){
           return colorR;
    }
    public String getColorL(){
           return colorL;
    }
    public void  setLado1(double l1){
           lado1=l1;
    }
    public void setLado2(double l2){
           lado2=l2;
    }
    public void setLado3(double l3){
           lado3=l3;
    }
    public void setColorR(String cR){
           colorR=cR;
    }
    public void setColorL(String cL){
           colorL=cL;
    }
    public double calcularPerimetro(){
       return lado1+lado2+lado3;
    }
    public double calcularArea(){
        double s = (lado1+lado2+lado3)/2;
        return Math.sqrt(s*(s-lado1)*(s-lado2)*(s-lado3));
       
    }
 }

