/**B - Genere un programa principal que cree una balanza e inicie una compra.
 * Lea información desde teclado correspondiente  a los ítems comprados (peso en kg y precio por kg)  
 * hasta que se ingresa uno con peso 0.  
 * Registre cada producto en la balanza. Al finalizar, informe el resumen de la compra. 
 * */
 
 import java.util.Scanner;
 public class Ej2balanzas{

   public static void main (String[]args){
    
   Scanner in = new Scanner (System.in); 
   int cantProd=0;
   double precioTotal=0, precioEnKg=0;
   System.out.println("Ingrese el peso en kg del producto: ");
   double pesoEnKg = in.nextDouble();
   while (pesoEnKg != 0){
       System.out.println("Ingrese el precio por kg del producto: ");
       precioEnKg = in.nextDouble();
       cantProd++;
       precioTotal= precioTotal + precioEnKg;
       System.out.println("Ingrese el peso en kg del producto: ");
       pesoEnKg = in.nextDouble();
    }
   Balanzas b = new Balanzas(pesoEnKg, precioEnKg, cantProd, precioTotal);
   System.out.println(b.DevolverResumenDeCompra());
}
}
 
 