
/**
 4- A- Modifique la clase Persona (ya implementada en la clase 2) agregando los cambios necesarios para que represente jugadores 
 de fútbol de un club. Todos los jugadores de futbol se caracterizan por tener además de los atributos de la clase 
 persona una estadística básica que consiste en el número de partidos jugados y el número de goles anotados. 

b)Incorpore los atributos número de partidos jugados y número de goles anotados junto a todos sus getters y setters.
*/
public class Jugadores
{   private String nombre;
    private int DNI;
    private int edad;
    private int partJugados;
    private int cantGoles;
    
    public Jugadores (String unNombre, int unDNI, int unaEdad, int unPartido, int unGol){
        nombre = unNombre;
        DNI = unDNI;
        edad = unaEdad; 
        partJugados = unPartido;
        cantGoles = unGol;
    }
    
    public Jugadores(){
     
    }

    public int getDNI() {
        return DNI;
    }

    public int getEdad() {
        return edad;
    }

    public String getNombre() {
        return nombre;
    }

    public int getPartidos (){
        return partJugados;
    }
    
    public int getGoles(){
        return cantGoles;
    }
    
    public void setDNI(int unDNI) {
        DNI = unDNI;
    }

    public void setEdad(int unaEdad) {
        edad = unaEdad;
    }

    public void setNombre(String unNombre) {
        nombre = unNombre;
    }
    
    public void setPartJugados (int unPartido){
        partJugados = unPartido;
    }
    
    public void setCantGoles (int unGol){
        cantGoles = unGol;
    }
    public String toString(){
        String aux; 
        aux = "Mi nombre es " + nombre + ", mi DNI es " + DNI + " y tengo " + edad + " años.";
        return aux;
    }
    
    
    
    
}