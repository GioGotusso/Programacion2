
/**
De cada solicitud se conoce: número de gestión (alfanumérico), fecha que se gestionó la solicitud, ingresos mensuales
declarados, cantidad de integrantes del grupo familiar, región (Patagonia, PampaHúmeda, PampaSeca, Cuyo,
SierrasPampeanas, NOA, Chaqueña, Mesopotamia) y de la persona que realizó la solicitud, se conoce: nombre, apellido
y CUIT
 */
public abstract class  Solicitud
{
    private String numGestion;
    private String fecha;
    private double ingresos;
    private int cantIntegrantes;
    private String region;
    private Persona infoPersona;

    public Solicitud(String numGestion,String fecha,double ingresos,int cantIntegrantes,String region,Persona infoPersona)
    {
        this.numGestion=numGestion;
        this.fecha=fecha;
        this.ingresos=ingresos;
        this.cantIntegrantes=cantIntegrantes;
        this.region=region;
        this.infoPersona=infoPersona;
    }
    public Solicitud()
    {
    }

    public void setNumGestion(String numGestion){
      this.numGestion=numGestion; 
    }
    public void setFecha(String fecha){
      this.fecha=fecha;
    }
    public void setIngresos(double ingresos){
      this.ingresos=ingresos;
    }
    public void setCantIntegrantes(int cantIntegrantes){
      this.cantIntegrantes=cantIntegrantes;
    }
    public void setRegion(String region){
      this.region=region;
    }
    public void setInfoPersona(Persona infoPersona){
      this.infoPersona=infoPersona;
    }
    public String getNumGestion(){
      return numGestion;  
    }
    public String getFecha(){
      return fecha;  
    }
    public double getIngresos(){
      return ingresos;  
    }
    public int getCantIntegrantes(){
      return cantIntegrantes;  
    }
    public String getRegion(){
      return region;  
    }
    public Persona getInfoPersona(){
      return infoPersona;  
    }
    public abstract double calcularGastoAprox ();
    public abstract boolean analisisSubsidio ();
}
