
/**
 a se registran, además de los datos del subsidio, el NIS (Número de Identificación de Sumistro), y la cantidad de
electrodomésticos
 */
public class Energia extends Solicitud
{
    
    private int nis;
    private int cantE;
    
    public Energia(int nis,int cantE,String numGestion,String fecha,double ingresos,int cantIntegrantes,String region,Persona infoPersona)
    {
        super(numGestion,fecha,ingresos,cantIntegrantes,region,infoPersona);
        this.nis=nis;
        this.cantE=cantE;
       
    }
    public Energia()
    {
       }

    public int getNis()
    {
        return nis;
    }
    public int getCantE()
    {
        return cantE;
    }
    public void setNis (int nis)
    {
        this.nis=nis;
    }
    public void setCantE (int cantE)
    {
        this.cantE=cantE;
    }
    /**- Si el ingreso mensual familiar declarado supera los 300000 pesos se calcula a partir de hacer 500 pesos
    por cada electrodoméstico que exista en el hogar, en cambio si el ingreso está entre 300000 y 150000, se
    calcula a partir de 100 pesos por la mitad de los electrodomésticos existentes además del 2% del ingreso
   familiar, finalmente si los ingresos son inferiores a 150000 se calcula el 1,5% del ingreso mensual además
   de un monto fijo de 400 pesos por cada integrante del grupo familiar.
   */
    public double calcularGastoAprox (){
       if (super.getIngresos() > 300000 ){
           return (500*this.cantE);
        }
        else 
            if(super.getIngresos() < 300000 && super.getIngresos() > 150000 ){
               return (100*(this.cantE/2)+(super.getIngresos()*2)/100);
            
            }
            else
             return (400*(super.getCantIntegrantes())+(super.getIngresos()*1.5)/100); 
    }
    /**La posibilidad de acceder al subsidio en el caso de la energía eléctrica se da por la siguiente ecuación:
el ingreso mensual familiar sobre la cantidad de integrantes no debe superar el 45% de dicho ingreso*/
   public boolean analisisSubsidio (){
          if (super.getIngresos()/super.getCantIntegrantes()<(super.getIngresos()*45)/100)
             return true;
          else return false;
    }
}
  

