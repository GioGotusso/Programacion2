
/**
 * Write a description of class Persona here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Persona
{
    // instance variables - replace the example below with your own
    private String nombre;
    private String apellido;
    private int dni;
    
    public Persona(String nombre,String apellido,int dni)
    {
       this.nombre=nombre;
       this.apellido=apellido;
       this.dni=dni;
    }
    public Persona(){
    }
    //getters y setters
    public void setNombre(String nombre){
      this.nombre=nombre; 
    }
    public void setApellido(String apellido){
      this.apellido=apellido;
    }
    public void setDni(int dni){
      this.dni=dni;
    }
    
    public String getNombre(){
      return nombre;  
    }
    public String getApellido(){
      return apellido;  
    }
    public int getDni(){
      return dni;  
    }
}
