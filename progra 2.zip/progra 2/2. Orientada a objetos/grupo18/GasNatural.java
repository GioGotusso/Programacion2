
/**
número de
medidor, el tamaño del hogar (en metros cuadrados) y cantidad de calefactores/estufas.
 */
public class GasNatural extends Solicitud
{
    private int numMedidor;
    private double metrosCuadrados;
    private int cantEstufas;
    public GasNatural(int numMedidor,double metrosCuadrados,int cantEstufas,String numGestion,String fecha,double ingresos,int cantIntegrantes,String region,Persona infoPersona)
    {
        super(numGestion,fecha,ingresos,cantIntegrantes,region,infoPersona);
        this.numMedidor=numMedidor;
        this.metrosCuadrados= metrosCuadrados;
        this.cantEstufas=cantEstufas;
    }
    public GasNatural()
    {
    }

    public void setNumMedidor(int numMedidor){
      this.numMedidor=numMedidor;
    }
    public void setMetrosCuadrados(double metrosCuadrados){
      this.metrosCuadrados= metrosCuadrados;
    } 
    public void setCantEstufas(int cantEstufas){
      this.cantEstufas=cantEstufas;
    }  
    public int getNumMedidor(){
      return numMedidor;  
    }
    public double getMetrosCuadrados(){
      return metrosCuadrados ;  
    }
    public int getCantEstufas(){
        return cantEstufas ;  
    }
    /**Gas natural
     * - Si el ingreso mensual familiar declarado supera los 300000 pesos se calcula a partir de hacer el producto
     * entre 250 pesos y la mitad de metros cuadrados de la propiedad sumado a 750 pesos por cada
     * calefactor/estufa, en cambio si el ingreso está entre 300000 y 150000, se calcula 100 pesos por un tercio
     * de los metros cuadrados más 500 pesos por cada calefactor/estufa, finalmente si los ingresos son
     * inferiores a 150000 se calcula el 2% del ingreso mensual y un monto fijo de 1000 pesos.
 */
    public double calcularGastoAprox (){
        if (super.getIngresos() > 300000 ){
           return (250*((this.metrosCuadrados/2)+(750* this.cantEstufas)));
        }
        else 
            if(super.getIngresos() < 300000 && super.getIngresos() > 150000 ){
               return (100*((this.metrosCuadrados/3)+(500* this.cantEstufas)));
            
            }
            else
             return ((super.getIngresos()*2)/100+(1000));    
    
    }
   /** el ingreso mensual familiar sobre la cantidad de
    * integrantes junto a la cantidad de calefactores/estufas, no debe superar el 40% del ingreso.*/
    public boolean analisisSubsidio (){
       if (super.getIngresos()/(super.getCantIntegrantes()+this.cantEstufas)<(super.getIngresos()*40)/100)
             return true;
          else return false;
    
    }
}
