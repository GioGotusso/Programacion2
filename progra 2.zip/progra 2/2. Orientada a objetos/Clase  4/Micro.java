
/**
- Definir una clase para representar micros. Un micro se caracteriza por su patente, destino, hora salida, una cantidad de asientos fija (20) 
para los que debe registrar su estado (es decir si está o no ocupado) y cantidad de asientos ocupados.  El micro puede ocuparse total o parcialmente.
a)  Defina métodos getters/setters para patente, destino y hora de salida.
b)  Implemente un constructor que permita inicializar el micro creado con una patente,  un destino y una hora de salida (recibidas como parámetro)
y sin pasajeros. 
c)  Implemente métodos para: 
i.  devolver la cantidad de asientos ocupados
ii. devolver si el micro está lleno
iii. validar un número de asiento recibido como parámetro
iv. devolver el estado de un nro. de asiento válido recibido como parámetro
v.  ocupar un nro. de asiento válido recibido como parámetro
vi. liberar un nro. de asiento válido recibido como parámetro
vii.    devolver el nro. del primer asiento libre

 */
public class Micro{
    
    private String patente;
    private String destino;
    private String hora;
    private boolean [] asientos;
    private int cantAsientos=0;

    public Micro (String patente, String destino, String hora){
        this.patente=patente;
        this.destino=destino;
        this.hora=hora;
        this.asientos= new boolean [20];
        int i;
        for (i=0; i<20; i++)
            asientos[i]=false;
    }
    
    public Micro (){
    }
    
    public String getPatente (){
        return patente;
    }
    
    public String getDestino (){
        return destino;
    }
    
    public String getHora(){
        return hora;
    }
    
    public void setPatente(String patente){
        this.patente=patente;
    }
    
    public void setDestino(String destino){
        this.destino=destino;
    }
    
    public void setHora(String hora){
        this.hora=hora;
    }
    //devolver la cantidad de asientos ocupados
    public int cantidadAsientos() {
        int i;
        for (i=0; i<20; i++)
            if (asientos[i])
                cantAsientos++;
        return cantAsientos;
    }
    //devolver si el micro está lleno
    public boolean estaLleno(){
        if (cantAsientos==20)
           return true;
        else
           return false;
    }
    //validar un número de asiento recibido como parámetro
    public boolean validarAsiento (int i){
        if (i >=0 && i<20)
            return true;
        else
            return false;
    }
    //devolver el estado de un nro. de asiento válido recibido como parámetro
    public String validarEstado (int i){
        String aux;
        if (asientos[i])
            aux = "El asiento "+i+" esta ocupado";
        else
            aux = "El asiento "+i+" esta libre";
            return aux;
        }    
    //ocupar un nro. de asiento válido recibido como parámetro 
    public void ocuparAsiento(int i){
        asientos[i]=true;
    }
    //liberar un nro. de asiento válido recibido como parámetro
    public void liberarAsiento(int i){
        asientos[i]=false;
    }
    //devolver el nro. del primer asiento libre
    public int primerAsLibre (){
        int i=0;
        while (asientos[i] && i<20)
          i++;
        return i;
    }    
}

    
