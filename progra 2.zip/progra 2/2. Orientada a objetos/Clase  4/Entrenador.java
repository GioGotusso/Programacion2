
/**
 A– Defina un constructor para la clase Entrenador (definida en la Act. 3 - Parte 1) que reciba los datos necesarios 
 (nombre, sueldo básico, cantidad de campeonatos ganados). Además defina un constructor nulo. 
 */
public class Entrenador {
    private String nombre;
    private double sueldo;
    private int cantCampGanados; 
    
    public Entrenador (String nombre, double sueldo, int cantCampGanados){
        this.nombre = nombre;
        this.sueldo = sueldo;
        this.cantCampGanados = cantCampGanados; 
    }
    
    public Entrenador(){
     
    }

    public double getSueldo() {
        return sueldo;
    }

    public int getCantCampGanados() {
        return cantCampGanados;
    }

    public String getNombre() {
        return nombre;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public void setCantCampGanados(int cantCampGanados) {
        this.cantCampGanados = cantCampGanados;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    //El sueldo se compone del sueldo básico, al cual se le adiciona un plus por campeonatos ganados 
    //(5000$ si ha ganado entre 1 y 4 campeonatos; $30.000 si ha ganado entre 5 y 10 campeonatos;
    //50.000$ si ha ganado más de 10 campeonatos).
    public double calcularSueldoACobrar(){
        double sueldoACobrar=0;
        if (cantCampGanados >= 1 && cantCampGanados<=4)
            sueldoACobrar=this.sueldo+5000;
        else if (cantCampGanados >= 5 && cantCampGanados <= 10)
            sueldoACobrar=this.sueldo+10000;
            else if (cantCampGanados > 10)
                sueldoACobrar=this.sueldo+50000;
        return sueldoACobrar;        
    }
}    
    