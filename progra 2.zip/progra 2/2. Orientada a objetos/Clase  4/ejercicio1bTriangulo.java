
/**
 B- Realice un programa que instancie un triángulo mediante los distintos constructores.
 */
import java.util.Scanner;
public class ejercicio1bTriangulo{
  public static void main(String []args){
   Scanner in = new Scanner(System.in);
   double lado1,lado2,lado3;
   String colorR,colorL;
   System.out.println("Ingrese lado 1 :");
   lado1 = in.nextDouble();
   System.out.println("Ingrese lado 2");
   lado2 = in.nextDouble();
   System.out.println("Ingrese lado 3 :");
   lado3 = in.nextDouble();
   System.out.println("Ingrese el color de relleno"); 
   colorR = in.next();
   in.nextLine();
   System.out.println("Ingrese el color de lineas"); 
   colorL = in.next();
   Triangulo info = new Triangulo (lado1,lado2,lado3,colorR,colorL);
   in.close();
   System.out.println ("El perimetro del triangulo es: "+info.calcularPerimetro());
   System.out.println ("El area del triangulo es: "+ info.calcularArea()); 
    }
    
 
}