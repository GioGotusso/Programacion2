
/**
 Realice un programa que cree un objeto persona con datos leídos desde teclado. 
 Luego muestre en consola la representación de ese objeto en formato String.  
 */
import java.util.Scanner;  //importo la funcionalidad de entrada
public class Ej1APersonas
{
    public static void main (String[]args)
    {
        Scanner in = new Scanner (System.in); //Declaro el Scanner e indico que se lee desde teclado 
        System.out.println ("Ingrese su edad: ");
        int edad = in.nextInt ();
        System.out.println ("Ingrese su dni: ");
        int dni = in.nextInt ();
        System.out.println ("Ingrese su nombre: ");
        String nombre = in.next();
        Persona p = new Persona(); //Relaciono el ejercicio con la clase Persona.
        p.setDNI (dni);                       /**seteo el dni*/
        p.setEdad (edad);                     /**seteo la edad*/
        p.setNombre (nombre);                 /**seteo el nombre*/
        System.out.println(p.toString());       /**RECORDAR: con el punto estoy enviando el mensaje a la clase Persona.*/
        in.close();  //cierro el Scanner                     
    }
  
    
}
