
/**
a) Implemente un programa que cargue un vector con los 325 partidos disputados en la superliga 2018/2019. 
Luego de la carga realizar los métodos que considere necesarios para informar:
b) La cantidad de partidos que ganó River.
c) El total de goles que realizó Boca jugando de local.
d) El porcentaje de partidos finalizados con empate. 

 */
import java.util.Scanner;
public class Ej4aPartido
{
    public static void main (String[]args)
    {
        Scanner in = new Scanner(System.in);
        Partido [] vector = new Partido [3]; //325
        int i;
        for (i=0; i<3; i++)
        {  
            System.out.println ("Ingrese el nombre del equipo local:");
            String eqLoc = in.next();
            System.out.println ("Ingrese el nombre del equipo visitante:");
            String eqVis = in.next();
            System.out.println("Ingrese la cantidad de goles del equipo local:");
            int golesLoc = in.nextInt();
            System.out.println("Ingrese la cantidad de goles del equipo visitante:");
            int golesVis = in.nextInt();
            vector[i]= new Partido (eqLoc,eqVis,golesLoc,golesVis);
        }
        in.close();
        System.out.print("River gano "+getGanoRiver(vector)+" partidos.");
        System.out.println("Boca realizo "+getGolesBocaLoc(vector)+" goles jugando de local.");
        System.out.println("El porcentaje de partidos finalizados con empate es: "+getEmpates(vector)+"%");
    }
    
    public static int getGanoRiver ( Partido vector[])
    {
        int i, cant=0;
        for (i=0; i<3; i++)
        {
            if (vector[i].getGanador().toLowerCase().equals("river"))
               cant++;
        }
        return cant;    
    }
    
    public static int getGolesBocaLoc (Partido vector[])
    {
        int i, cant=0;
        for (i=0; i<3; i++)
        {
            if (vector[i].getLocal().toLowerCase().equals("boca"))
            {
                cant+=vector[i].getGolesLocal();
            }
        }
        return cant;
    }
    
    public static double getEmpates (Partido vector[])
    {
        int i, cant=0;
        double prom=0;
        for (i=0; i<3; i++)
        {
            if (vector[i].hayEmpate()==true)
               cant++;
        }
        prom=(cant*325)/100;
        return prom;
    }
    
}
