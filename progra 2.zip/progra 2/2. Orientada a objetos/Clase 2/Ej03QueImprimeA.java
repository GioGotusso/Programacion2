
/**
a)¿Qué imprime cada uno?
b)¿Qué efecto tiene la asignación utilizada con objetos?  
c)¿Qué se puede concluir acerca de la comparación con == y != utilizada con objetos?
d) ¿Qué retorna el mensaje equals cuando se le envía a un String?   

 */
public class Ej03QueImprimeA {
    public static void main(String[] args) {
        String saludo1=new String("hola");
        String saludo2=new String("hola");
        System.out.println(saludo1 == saludo2); //imprime false dado que compara la ubicacion en memoria ram
        System.out.println(saludo1 != saludo2); //imprime true dado que estan en distintas ubicaciones de memoria ram
        System.out.println(saludo1.equals(saludo2)); //imprime true dado que compara el contenido de los objetos 
    } 
}


