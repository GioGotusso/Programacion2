
/**
a)¿Qué imprime cada uno?
b)¿Qué efecto tiene la asignación utilizada con objetos?  
c)¿Qué se puede concluir acerca de la comparación con == y != utilizada con objetos?
d) ¿Qué retorna el mensaje equals cuando se le envía a un String?   

 */

public class Ej03QueImprimeB {
    public static void main(String[] args) {
        Persona p1; 
        Persona p2;
        p1 = new Persona();
        p1.setNombre("Pablo Sotile"); //le asigno un nombre, dni y edad a la persona 1
        p1.setDNI(11200413);
        p1.setEdad(40);
        p2 = new Persona();
        p2.setNombre("Julio Toledo"); //le asigno un nombre, dni y edad a la persona 2
        p2.setDNI(22433516);
        p2.setEdad(51);
        p1 = p2; //a p1 le asigno la posicion en memoria de p2
        p1.setEdad( p1.getEdad() + 1 ); // edad 52
        System.out.println(p2.toString()); // mi nombre es Julio Toledo, mi DNI es: 22433516 y tengo 52 años
        System.out.println(p1.toString()); // mi nombre es Julio Toledo, mi DNI es: 22433516 y tengo 52 años
        System.out.println( (p1 == p2) );  //true (comparten misma posicion de memoria)
    } }
