/**
2-   Utilizando la clase Persona (ya implementada). 
a) Realice un programa que almacene en un vector 15 personas. La información de cada persona debe leerse de teclado. 
Luego de almacenar la información:    
b) Agregue un método que devuelva la cantidad de personas mayores de 65 años.
c) Agregue un método que devuelva la representación de la persona con menor DNI.
d) Muestre desde el programa principal la cantidad de personas mayores de 65 años y muestre también la representación 
por pantalla de una persona con menor DNI.

 */

//inciso A)
import java.util.Scanner;
public class Ej2PersonaPreg
{
    public static void main (String[]args)
    {
        Scanner in = new Scanner (System.in);
        Persona [] vector = new Persona [3];  //Declaro un vector de 15 personas
        int i;
        for (i=0; i<3; i++)
        {
            System.out.println ("Ingrese la edad:");
            int edad = in.nextInt();
            System.out.println ("Ingrese el Dni:");
            int dni = in.nextInt();
            System.out.println ("Ingrese el nombre:");
            String nombre = in.next();
            vector [i] = new Persona (nombre,dni,edad);  //En cada posicion del vector guardo una nueva persona.                 
        }
        in.close();
        System.out.println ("La cantidad de personas mayores a 65 años es: "+getMayores65(vector));
        System.out.println ("Persona con menor DNI: "+getMenorDni(vector));
    }
    
    public static int getMayores65 (Persona vector[])
    {
        int i, cont=0;
        for (i=0; i<3; i++)
            if (vector[i].getEdad()>65)
                cont++;
    
    return cont;
    }
    
    public static String getMenorDni (Persona vector[])
    {   int min=99999999, i;
        Persona mindni = new Persona();
        for (i=0; i<3; i++)
            if (vector[i].getDNI()<min)
            {
                min=vector[i].getDNI();
                mindni=vector[i];
            }
        return mindni.toString();    
    }
}
