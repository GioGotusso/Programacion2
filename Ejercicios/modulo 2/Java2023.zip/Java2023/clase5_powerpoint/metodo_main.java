public class metodo_main
{
    public static void main(String[]args)
    {
        Punto p= new Punto(10,20);
        Triangulo triangulo= new Triangulo(5.0,10.2,8.0,"rosa","negro",p);
        Circulo circulo = new Circulo (30,"amarillo","negro",p);
        System.out.println("el perimetro del triangulo es: "+triangulo.calcularPerimetro());
        System.out.println("el area del triangulo es: "+triangulo.calcularArea());
        System.out.println("el perimetro del circulo es: "+circulo.calcularPerimetro());
        System.out.println("el area del circulo es: "+circulo.calcularArea());
        triangulo.dibujar();
        circulo.dibujar();
    }
    }
