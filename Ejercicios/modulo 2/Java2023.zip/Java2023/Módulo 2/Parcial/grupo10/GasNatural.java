public class GasNatural extends Solicitud{
    private int num;
    private double tamaño;
    private int cantCE;
    
    //CONSTRUCTORES
     public GasNatural(){
         
     }
     public GasNatural(String numGestion, String fecha, double ingresosM, int integrantes, String region, Persona persona, int num, double tamaño, int cantCE){
         super(numGestion,fecha,ingresosM,integrantes,region,persona);
         this.num=num;
         this.tamaño=tamaño;
         this.cantCE=cantCE;
     }
    
     //METODOS
     public int getNum(){
         return num;
     }
     
     public double getTamaño(){
         return tamaño;
     }
     
     public int getCantCE(){
         return cantCE;
     }
     
     public void setNum(int num){
         this.num=num;
     }
     
     public void setTamaño(double tamaño){
         this.tamaño=tamaño;
     }
     
     public void setCantCE(int cantCE){
         this.cantCE=cantCE;
     }
     
     public double calcularTarifaSubsidio(){
         if(super.getIngresosM()>300000){
             return (250 * (tamaño/2) + (750*cantCE));
         }
         else{
             if((super.getIngresosM()>=150000) && (super.getIngresosM()<=300000)){
                 return (100* (tamaño/3) + (500*cantCE));
             } else{
                 return ((super.getIngresosM() * 0.02) + 1000);
             }
         }
     }
     
     public boolean accesoSubsidio(){
         return (((super.getIngresosM() / (super.getIntegrantes()+cantCE)) < (super.getIngresosM()*0.40))&&TarifasNacionalesPorRegion.puedeAccederAlSubsidio(super.getIngresosM(),super.getRegion()));
     }
     
     public String imprimir(){
         String aux=(super.getPersona().toString()+" con número de gestión "+super.getNumGestion()+" realizó una solicitud de gas natural con fecha "+super.getFecha()+". Sus ingresos mensuales declarados son: "+super.getIngresosM()+". Su familia tiene "+super.getIntegrantes()+" integrantes. Su región es "+super.getRegion()+". Numero de medidor "+num+". Tamaño del hogar "+tamaño+" metros cuadrados y posee "+cantCE+" calefactores/estufas.");
         if(accesoSubsidio()){
             return (aux+" Obtuvo el subsidio y debe pagar: "+calcularTarifaSubsidio());
         }
         else{
             return (aux+" No obtuvo el subsidio y debe pagar: "+super.calcularTarifaPlena());
         }
     }

}