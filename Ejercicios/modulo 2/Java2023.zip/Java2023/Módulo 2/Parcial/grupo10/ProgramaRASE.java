import java.util.Scanner;
public class ProgramaRASE{
    public static void main (String[]args){
        Scanner in = new Scanner (System.in);
        int i,SOLICITUDES=5;
        Solicitud[] v= new Solicitud[SOLICITUDES];
        //CARGA DE SOLICITUDES
        for(i=0;i<SOLICITUDES;i++){
            v[i]=leerSolicitud(in);
            System.out.println();
        }
        
        //IMPRESIÓN DE LISTADO
        for(i=0;i<SOLICITUDES;i++){
            System.out.println(v[i].imprimir());
        }
        in.close();
    }
    
    public static Solicitud leerSolicitud(Scanner in){
        String numGestion,fecha,region,solicitud;
        double ingresosM,tamaño;
        int integrantes,num,cantCE,cantE,NIS;
        Persona p = leerPersona(in);
        System.out.println("DATOS DE LA SOLICITUD");
        System.out.print("Ingrese número de gestión: ");
        numGestion=in.next();
        in.nextLine();
        System.out.print("Ingrese fecha: ");
        fecha=in.next();
        System.out.print("Ingrese ingresos mensuales: ");
        ingresosM=in.nextDouble();
        System.out.print("Ingrese integrantes del grupo familiar: ");
        integrantes=in.nextInt();
        System.out.print("Ingrese region: ");
        region=in.next();
        System.out.print("Ingrese solicitud a ingresar (GasNatural/EnergiaElectrica) ");
        solicitud=in.next();
        if(solicitud.equals("GasNatural")){
            System.out.print("Ingrese número de medidor: ");
            num=in.nextInt();
            System.out.print("Ingrese tamaño del hogar (en metros cuadrados): ");
            tamaño=in.nextDouble();
            System.out.print("Ingrese cantidad de calefactores y estufas: ");
            cantCE=in.nextInt();
            return (new GasNatural(numGestion,fecha,ingresosM,integrantes,region,p,num,tamaño,cantCE));
        }
        else{
            System.out.print("Ingrese Número de Identificación de Suministro(NIS): ");
            NIS=in.nextInt();
            System.out.print("Ingrese cantidad de electrodomésticos: ");
            cantE=in.nextInt();
            return (new EnergiaElectrica(numGestion,fecha,ingresosM,integrantes,region,p,NIS,cantE));
        }   
    }
    
    public static Persona leerPersona(Scanner in){
        String nom,ape;
        int CUIT;
        System.out.println("DATOS DE LA PERSONA");
        System.out.print("Ingrese nombre: ");
        nom=in.next();
        in.nextLine();
        System.out.print("Ingrese apellido: ");
        ape=in.next();
        System.out.print("Ingrese CUIT: ");
        CUIT=in.nextInt();
        return (new Persona(nom,ape,CUIT));
    }
}