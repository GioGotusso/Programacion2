public class EnergiaElectrica extends Solicitud{
    private int NIS;
    private int cantE;
    
    //CONSTRUCTORES
     public EnergiaElectrica(){
         
     }
     public EnergiaElectrica(String numGestion, String fecha, double ingresosM, int integrantes, String region, Persona persona, int NIS, int cantE){
         super(numGestion,fecha,ingresosM,integrantes,region,persona);
         this.NIS=NIS;
         this.cantE=cantE;
     }
     
    //METODOS
     public int getNIS(){
         return NIS;
     }
     
     public int getCantE(){
         return cantE;
     }
     
     public void setNIS(int NIS){
         this.NIS=NIS;
     }
     
     public void setCantE(int cantE){
         this.cantE=cantE;
     }
     
     public double calcularTarifaSubsidio(){
         if(super.getIngresosM()>300000){
             return (500* cantE);
         }
         else{
             if((super.getIngresosM()>=150000)&&(super.getIngresosM()<=300000)){
                 return (100*(cantE/2)+(super.getIngresosM() * 0.02));
             }
             else{
                 return ((super.getIngresosM()*0.015)+(400*super.getIntegrantes()));
             }
         }
     }
     
     public boolean accesoSubsidio(){
         return ((super.getIngresosM()/super.getIntegrantes() < (super.getIngresosM()*0.45))&&TarifasNacionalesPorRegion.puedeAccederAlSubsidio(super.getIngresosM(),super.getRegion()));
     }
     
     public String imprimir(){
         String aux=(super.getPersona().toString()+" con número de gestión "+super.getNumGestion()+ "realizó una solicitud de energía eléctrica con fecha "+super.getFecha()+". Sus ingresos mensuales declarados son: "+super.getIngresosM()+". Su familia tiene "+super.getIntegrantes()+" integrantes. Su región es "+super.getRegion()+". NIS: "+NIS+" y posee "+cantE+" electrodomesticos.");
         if(accesoSubsidio()){
             return (aux+" Obtuvo el subsidio y debe pagar: "+calcularTarifaSubsidio());
         }
         else{
             return (aux+" No obtuvo el subsidio y debe pagar: "+super.calcularTarifaPlena());
         }
     }
     
}