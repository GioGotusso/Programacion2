public abstract class Solicitud{
    private String numGestion;
    private String fecha;
    private double ingresosM;
    private int integrantes;
    private String region;
    private Persona persona;
    
    //CONSTRUCTORES
     public Solicitud(){
         
     }
     public Solicitud(String numGestion, String fecha, double ingresosM, int integrantes, String region, Persona persona){
         this.numGestion=numGestion;
         this.fecha=fecha;
         this.ingresosM=ingresosM;
         this.integrantes=integrantes;
         this.region=region;
         this.persona=persona;
     }
    
     //METODOS
      public String getNumGestion(){
          return numGestion;
      }
      
      public String getFecha(){
          return fecha;
      }
      
      public double getIngresosM(){
          return ingresosM;
      }
      
      public int getIntegrantes(){
          return integrantes;
      }
      
      public String getRegion(){
          return region;
      }
      
      public Persona getPersona(){
          return persona;
      }
      
      public void setNumGestion(String numGestion){
          this.numGestion=numGestion;
      }
      
      public void setFecha(String fecha){
          this.fecha=fecha;
      }
      
      public void setIngresosM(double ingresosM){
          this.ingresosM=ingresosM;
      }
      
      public void setIntegrantes(int integrantes){
          this.integrantes=integrantes;
      }
      
      public void setRegion(String region){
          this.region=region;
      }
      
      public void setPersona(Persona persona){
          this.persona=persona;
      }
      
      public double calcularTarifaPlena(){
         return (ingresosM*0.05);
      }
      
      abstract double calcularTarifaSubsidio();
      abstract String imprimir();
}
  

