public class Libro extends Ejemplar{
    private String titulo;
    private int cantC;
    private boolean edicion;
    
    public Libro(){
        
    }
    
    public Libro(int cod, int cant, String resumen, int año, Responsable info, String titulo, int cantC, boolean edicion){
        super(cod,cant,resumen,año,info);
        this.titulo=titulo;
        this.cantC=cantC;
        this.edicion=edicion;
    }
    
    public Libro(int cod, int cant, String resumen, Responsable info, String titulo, int cantC, boolean edicion){
        super(cod,cant,resumen,info);
        this.titulo=titulo;
        this.cantC=cantC;
        this.edicion=edicion;
    }
    
    public String getTitulo(){
        return titulo;
    }
    
    public int getCantidadC(){
        return cantC;
    }
    
    public boolean getEdicion(){
        return edicion;
    }
    
    public void setTitulo(String titulo){
        this.titulo=titulo;
    }
    
    public void setCantidadC(int cantC){
        this.cantC=cantC;
    }
    
    public void setEdicion(boolean edicion){
        this.edicion=edicion;
    }
    
    public String imprimir(){
        return ("Codigo identificatorio: "+super.getCodigo()+" | Titulo: "+titulo+" | Nombre del responsable: "+super.getResponsable().getNombre());
    }
    
    public void publicar(){
        super.setAño(2022);
        if(edicion){
            titulo=(titulo+" - De Bolsillo");
        }
    }
}