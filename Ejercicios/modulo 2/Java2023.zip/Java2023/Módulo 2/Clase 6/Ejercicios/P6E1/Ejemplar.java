public abstract class Ejemplar{
    private int cod;
    private int cant;
    private String resumen;
    private int año;
    private Responsable info;
    
    public Ejemplar(){
        
    }
    
    public Ejemplar(int cod, int cant, String resumen, int año, Responsable info){
        this(cod,cant,resumen,info);
        this.año=año;
 
    }
    
    public Ejemplar(int cod, int cant, String resumen, Responsable info){
        this.cod=cod;
        this.cant=cod;
        this.resumen=resumen;
        this.año=0;
        this.info=info;
    }
    
    public int getCodigo(){
        return cod;
    }
    
    public int getCantidad(){
        return cant;
    }
    
    public String getResumen(){
        return resumen;
    }
    
    public Responsable getResponsable(){
        return info;
    }
        
    public int getAño(){
        return año;
    }
    
    public void setCodigo(int cod){
        this.cod=cod;
    }
    
    public void setCantidad(int cant){
        this.cant=cant;
    }
    
    public void setResumen(String resumen){
        this.resumen=resumen;
    }
    
    public void setAño(int año){
        this.año=año;
    }
    
    public void setResponsable(Responsable info){
        this.info=info;
    }
    
    abstract String imprimir();
    abstract void publicar();
}