import java.util.Scanner;
public class ProgramaEditorial{
public static void main (String[]args){
    Scanner in = new Scanner(System.in);
    int EJEMPLAR,i,cod,cantPaginas,año=0,dni,cantArticulos=0,cantCapitulos=0,num=0;
    boolean edicion=false,publi;
    String resumen,nombreR,apellidoR, titulo=".", nombre=".",ej=".";
    System.out.print("Ingrese cantidad de ejemplares: ");
    EJEMPLAR=in.nextInt();
    System.out.println();
    Ejemplar[] vector =new Ejemplar[EJEMPLAR];
    for(i=0;i<EJEMPLAR;i++){
        System.out.print("Ingrese codigo identificatorio: ");
        cod=in.nextInt();
        System.out.print("Ingrese cantidad de paginas: ");
        cantPaginas=in.nextInt();
        System.out.print("Ingrese resumen del ejemplar: ");
        resumen=in.nextLine();
        in.nextLine();
        System.out.print("Ingrese si el ejemplar fue publicado: ");
        publi=in.nextBoolean();
        if(publi){
            System.out.print("Ingrese año de publicación: ");
            año=in.nextInt();
        }
        System.out.print("Ingrese nombre del responsable: ");
        nombreR=in.next();
        in.nextLine();
        System.out.print("Ingrese apellido del responsable: ");
        apellidoR=in.next();
        System.out.print("Ingrese DNI del responsable:");
        dni= in.nextInt();
        Responsable responsable = new Responsable(dni,nombreR,apellidoR);
        System.out.print("Ingrese ejemplar a ingresar: ");
        ej=in.next();
        in.nextLine();
 
        if(ej.equals("Libro")){
            System.out.print("Ingrese titulo del libro: ");
            titulo=in.nextLine();
            System.out.print("Ingrese cantidad de capitulos: ");
            cantCapitulos=in.nextInt();
            System.out.print("Ingrese si es edición de bolsillo: ");
            edicion=in.nextBoolean();
        }
        else{
            System.out.print("Ingrese nombre de la revista: ");
            nombre=in.nextLine();
            if(publi){
                System.out.print("Ingrese numero de volumen: ");
                num=in.nextInt();
            }
            System.out.print("Ingrese cantidad de articulos: ");
            cantArticulos=in.nextInt();
        }
        if((publi)&&(ej.equals("Libro"))){
            vector[i] = new Libro(cod,cantPaginas,resumen,año,responsable,titulo,cantCapitulos,edicion);
        }
        else{
            if((!(publi))&&(ej.equals("Libro"))){
                 vector[i]= new Libro(cod,cantPaginas,resumen,responsable,titulo,cantCapitulos,edicion); 
                 
            }
            else{
                if((publi)&&(ej.equals("Revista"))){
                vector[i] = new Revista(cod,cantPaginas,resumen,año,responsable,nombre,num,cantArticulos); 
                }
                else{
                    vector[i] = new Revista(cod,cantPaginas,resumen,responsable,nombre,num,cantArticulos); 
                }
            }
        }
        System.out.println();
    }
    for(i=0;i<EJEMPLAR;i++){
        System.out.println(vector[i].imprimir());
        System.out.println();
    }
    System.out.println("Los ejemplares publicados son: ");
    for(i=0;i<EJEMPLAR;i++){
        if(vector[i].getAño()==0){
            vector[i].publicar();
            System.out.println(vector[i].imprimir());
            System.out.println();
        }
    }
}
}
