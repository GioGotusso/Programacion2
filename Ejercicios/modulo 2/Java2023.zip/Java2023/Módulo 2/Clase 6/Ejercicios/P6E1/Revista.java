public class Revista extends Ejemplar{
    private String nombre;
    private int num;
    private int cantA;
    
    public Revista(){
        
    }
    
    public Revista(int cod, int cant, String resumen, int año, Responsable info, String nombre,int num, int cantA){
        super(cod,cant,resumen,año,info);
        this.num= num;
        this.nombre=nombre;
        this.cantA=cantA;
    }
    
    public Revista(int cod, int cant, String resumen, Responsable info, String nombre, int num, int cantA){
        super(cod,cant,resumen,info);
        this.nombre=nombre;
        this.num=0;
        this.cantA=cantA;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public int getNumero(){
        return num;
    }
    
    public int getCantidadArticulo(){
        return cantA;
    }
    
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    
    public void setNumero(int num){
        this.num=num;
    }
    
    public void setCantidadArticulo(int cantA){
        this.cantA=cantA;
    }
    
    public String imprimir(){
        return ("Nombre: "+nombre+ " | Numero de volumen: "+num);
    }
    
    public void publicar(){
        super.setAño(2022);
        num=Generador.getNroVolumen();
    }
}

