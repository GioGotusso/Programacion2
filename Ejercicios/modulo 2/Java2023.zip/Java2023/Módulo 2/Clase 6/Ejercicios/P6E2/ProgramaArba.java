import java.util.Scanner;
public class ProgramaArba{
    public static void main (String[]args){
        Scanner in = new Scanner(System.in);
        int i;
        Propietario p=null;
        Automotor a=null;
        Embarcacion e=null;
        String vehiculo;
        System.out.print("Ingrese cantidad de vehiculos a ingresar: ");
        int CANT=in.nextInt();
        System.out.println();
        Vehiculo[] v= new Vehiculo[CANT];
        for(i=0;i<CANT;i++){
            lecturaPropietario(p,in);
            System.out.print("Ingrese vehiculo a ingresar: ");
            vehiculo=in.next();
            if(vehiculo.equals("Automotor")){
                v[i]=lecturaAutomotor(a,p,in);
            }
            else{
                v[i]=lecturaEmbarcacion(e,p,in);
            }
            System.out.println();
        }
        for(i=0;i<CANT;i++){
            System.out.println("Monto a pagar: "+v[i].calcularImpuesto());
        }
        in.close();
    }
    
    public static Propietario lecturaPropietario(Propietario p,Scanner in){
        System.out.print("Ingrese CIT del propietario: ");
        int CIT=in.nextInt();
        System.out.print("Ingrese nombre del propietario: ");
        String nombre=in.next();
        in.nextLine();
        System.out.print("Ingrese apellido del propietario: ");
        String apellido=in.next();
        p= new Propietario(nombre,apellido,CIT);
        return p;
    }
    
    public static Automotor lecturaAutomotor(Automotor a, Propietario p, Scanner in){
        System.out.print("Ingrese año de fabricacion: ");
        int año=in.nextInt();
        System.out.print("Ingrese importe basico: ");
        double importe=in.nextDouble();
        System.out.print("Ingrese patente: ");
        String patente=in.next();
        System.out.print("Ingrese importe adicional: ");
        double importeA=in.nextDouble();
        System.out.print("Ingrese descripcion: ");
        String descripcion=in.next();
        a=new Automotor(año,importe,p,patente,importeA,descripcion);
        return a;
    }
    
    public static Embarcacion lecturaEmbarcacion(Embarcacion e, Propietario p, Scanner in){
        System.out.print("Ingrese año de fabricacion: ");
        int año=in.nextInt();
        System.out.print("Ingrese importe basico: ");
        double importe=in.nextDouble();
        System.out.print("Ingrese codigo del Registro Especial de Yates (REY): ");
        int codigo=in.nextInt();
        System.out.print("Ingrese nombre de la embarcacion: ");
        String nombre=in.nextLine();
        in.nextLine();
        System.out.print("Ingrese tipo de embarcacion: ");
        String tipo=in.next();
        System.out.print("Ingrese eslora: ");
        double eslora=in.nextDouble();
        System.out.print("Ingrese tonelaje: ");
        double tonelaje=in.nextDouble();
        System.out.print("Ingrese valor declarado: ");
        double valor=in.nextDouble();
        e=new Embarcacion(año,importe,p,codigo,nombre,tipo,eslora,tonelaje,valor);
        return e;
    }
}