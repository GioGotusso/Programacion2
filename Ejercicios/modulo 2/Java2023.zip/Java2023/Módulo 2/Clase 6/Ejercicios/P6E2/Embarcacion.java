public class Embarcacion extends Vehiculo{
    private int REY;
    private String nombre;
    private String tipo;
    private double eslora;
    private double tonelaje;
    private double valor;
    
     public Embarcacion(){
         
     }
     
     public Embarcacion(int año, double importe, Propietario propietario, int REY, String nombre, String tipo, double eslora, double tonelaje, double valor){
         super(año,importe,propietario);
         this.REY=REY;
         this.nombre=nombre;
         this.tipo=tipo;
         this.eslora=eslora;
         this.tonelaje=tonelaje;
         this.valor=valor;
     }
     
     public void setREY(int REY){
         this.REY=REY;
     }
     
     public void setNombre(String nombre){
         this.nombre=nombre;
     }
     
     public void setTipo(String tipo){
         this.tipo=tipo;
     }
     
     public void setEslora(double eslora){
         this.eslora=eslora;
     }
     
     public void setTonelaje(double tonelaje){
         this.tonelaje=tonelaje;
     }
     
     public void setValor(double valor){
         this.valor=valor;
     }
     
     public int getREY(){
         return REY;
     }
     
     public String getNombre(){
         return nombre;
     }
     
     public String getTipo(){
         return tipo;
     }
     
     public double getEslora(){
         return eslora;
     }
     
     public double getTonelaje(){
         return tonelaje;
     }
     
     public double getValor(){
         return valor;
     }
     
     public double calcularImpuesto(){
         if(valor<6000){
             return (valor*0.04);
         }else{
             if((valor>=6000)&&(valor<=180000)){
                 return (valor*0.02);
             }else{
                 return (valor*0.05);
             }
         }
     }
}