import java.util.Scanner;
public class P3E3{
public static void main (String [] args){
    Scanner in = new Scanner(System.in);
    System.out.print("Ingrese nombre del entrenador: ");
    String nombre = in.next();
    System.out.print("Ingrese sueldo del entrenador: ");
    double sueldo = in.nextDouble();
    System.out.print("Ingrese campeonatos del entrenador: ");
    int camp = in.nextInt();
    Entrenador e = new Entrenador(nombre,sueldo,camp);
    System.out.println();
    System.out.println("El nombre del entrenador es "+e.getNombre());
    System.out.println("El sueldo del entrenador es "+e.getSueldo());
    System.out.println("La cantidad de campeonatos del entrenador es de "+e.getCampeonatos());
    System.out.println("El sueldo total del entrenador es de "+e.calcularSueldoACobrar());
    in.close();
}
}