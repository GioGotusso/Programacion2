import java.util.Scanner;
public class P3E4{
public static void main (String[]args){
    Scanner in = new Scanner(System.in);
    Jugador[] vectorJ = new Jugador[50];
    int i;
    int dni,edad,part,gol;
    String nombre;
    for(i=0;i<50;i++){
        System.out.print("Ingrese nombre: ");
        nombre = in.next();
        System.out.print("Ingrese DNI: ");
        dni = in.nextInt();
        System.out.print("Ingrese edad: ");
        edad = in.nextInt();
        System.out.print("Ingrese partidos jugados: ");
        part = in.nextInt();
        System.out.print("Ingrese goles: ");
        gol = in.nextInt();
        vectorJ[i]=new Jugador(nombre,dni,edad,part,gol);  
    }
    System.out.println("La cantidad de jugadores con mas de 100 partidos jugados es de "+masCien(vectorJ));
}
public static int masCien (Jugador[] v){
    int cont=0;
    int i;
    for(i=0;i<50;i++){
        if(v[i].getPartidos() > 100){
            cont++;
        }
    }
    return cont;
}
}