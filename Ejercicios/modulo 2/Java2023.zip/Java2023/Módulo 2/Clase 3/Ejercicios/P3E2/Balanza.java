public class Balanza {
    private double monto;
    private int cantidad;

    
    public Balanza(){
        
    }
    
    public void iniciarCompra(){
        monto=0;
        cantidad=0;
    }
    
    public void registrarCompra(double pesoEnKg, double precioPorKg){
        cantidad++;
        monto= monto + (pesoEnKg*precioPorKg);
    }
    
    public double devolverMontoAPagar(){
       return monto; 
    }
    
    public String devolverResumenDeCompra(){
        return ("Total a pagar "+devolverMontoAPagar()+" por la compra de "+cantidad+" productos");
    }

}