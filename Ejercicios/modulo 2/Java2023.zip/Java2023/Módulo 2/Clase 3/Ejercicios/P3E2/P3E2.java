import java.util.Scanner;
public class P3E2{
public static void main (String[] args){
    Scanner in = new Scanner(System.in);
    Balanza b = new Balanza();
    System.out.print("Ingrese precio por kilo del item: ");
    double precioKg= in.nextDouble();
    System.out.print("Ingrese peso en kilos del item: ");
    double pesoKg = in.nextDouble();
    while (pesoKg!=0){
        b.registrarCompra(pesoKg,precioKg);
        System.out.print("Ingrese precio por kilo del item: ");
        precioKg= in.nextDouble();
        System.out.print("Ingrese peso en kilos del item: ");
        pesoKg = in.nextDouble();

    }
    System.out.println();
    System.out.println(b.devolverResumenDeCompra());
    in.close();
}
}