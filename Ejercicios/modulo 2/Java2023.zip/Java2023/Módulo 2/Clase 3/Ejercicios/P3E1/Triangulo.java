public class Triangulo{
    private double lado1;
    private double lado2;
    private double lado3;
    private String cRelleno;
    private String cLinea;
    
    public Triangulo(double unLado1, double unLado2, double unLado3, String unColorR,String unColorL){
        setLado1(unLado1);
        setLado2(unLado2);
        setLado3(unLado3);
        setColorRelleno(unColorR);
        setColorLinea(unColorL);
    }
    
    public Triangulo(){
        
    }
    
    public double getLado1(){
        return lado1;
    }
    
    public double getLado2(){
        return lado2;
    }
    
    public double getLado3(){
        return lado3;
    }
    
    public String getColorRelleno(){
        return cRelleno;
    }
    
    public String getColorLinea(){
        return cLinea;
    }
    
    public void setLado1(double unLado1){
        lado1=unLado1;
    }
    
    public void setLado2(double unLado2){
        lado2=unLado2;
    }
    
    public void setLado3(double unLado3){
        lado3=unLado3;
    }
    
    public void setColorRelleno(String unColorRelleno){
        cRelleno=unColorRelleno;
    }
    
    public void setColorLinea(String unColorLinea){
        cLinea=unColorLinea;
    }
    
    private double calcularS (){
        return (lado1+lado2+lado3)/2;
    }
    
    public double calcularArea(){
        double s=calcularS();
        return (Math.sqrt(s*(s-lado1)*(s-lado2)*(s-lado3)));
    }
    
    public double calcularPerimetro(){
        return (lado1+lado2+lado3);
    }
}