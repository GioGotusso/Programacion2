import java.util.Scanner;
public class P3E1{
public static void main (String[] args){
    Scanner in = new Scanner(System.in);
    System.out.print("Ingrese medida del lado 1: ");
    double lado1= in.nextDouble();
    System.out.print("Ingrese medida del lado 2: ");
    double lado2= in.nextDouble();
    System.out.print("Ingrese medida del lado 3: ");
    double lado3= in.nextDouble();
    System.out.print("Ingrese color del relleno del triangulo: ");
    String colorR = in.next();
    System.out.print("Ingrese color de lineas del triangulo: ");
    String colorL = in.next();
    Triangulo t = new Triangulo(lado1,lado2,lado3,colorR,colorL);
    System.out.println();
    System.out.println("El valor del primer lado es de "+t.getLado1());
    System.out.println("El valor del segundo lado es de "+t.getLado2());
    System.out.println("El valor del tercer lado es de "+t.getLado3());
    System.out.println("El color del relleno es "+t.getColorRelleno());
    System.out.println("El color de lineas es "+t.getColorLinea());
    System.out.println();
    System.out.println("El area de triangulo es de "+t.calcularArea());
    System.out.println("El perimetro del triangulo es de "+t.calcularPerimetro());
    in.close();
}
}