import java.util.Scanner;
public class P3extra{
public static void main (String[]args){
    Scanner in = new Scanner (System.in);
    System.out.print("Ingrese cantidad de productos a agregar: ");
    int cant=in.nextInt();
    Producto [] vector = new Producto [cant];
    int i,codigo,unidad;
    String nombre,descripcion,marca;
    for(i=0;i<cant;i++){
        System.out.print("Ingrese codigo del producto: ");
        codigo= in.nextInt();
        System.out.print("Ingrese nombre del producto: ");
        nombre=in.next();
        in.nextLine();
        System.out.print("Ingrese descripcion del producto: ");
        descripcion= in.nextLine();
        System.out.print("Ingrese marca del producto: ");
        marca=in.next();
        System.out.print("Ingrese stock del producto: ");
        unidad=in.nextInt();
        vector[i]=new Producto(codigo,nombre,descripcion,marca,unidad);
        System.out.println();
    }
    System.out.println();
    for (i=0;i<cant;i++){
        System.out.println("Codigo: "+vector[i].getCodigo());
        System.out.println("Nombre: "+vector[i].getNombre());
        System.out.println("Descripcion: "+vector[i].getDescripcion());
        System.out.println("Marca: "+vector[i].getMarca());
        System.out.println("Stock: "+vector[i].getUnidades());
        System.out.println();
    }
    if(incrementarStock(vector,cant)){
        System.out.println("Se incrementó el stock");
    }
    else{
        System.out.println("El elemento no se encontraba en la lista");
    }
    System.out.println();
    for (i=0;i<cant;i++){
        System.out.println("Codigo: "+vector[i].getCodigo());
        System.out.println("Nombre: "+vector[i].getNombre());
        System.out.println("Descripcion: "+vector[i].getDescripcion());
        System.out.println("Marca: "+vector[i].getMarca());
        System.out.println("Stock: "+vector[i].getUnidades());
    }
    in.close();
    }
public static boolean incrementarStock(Producto[] v, int cant){
    Scanner in = new Scanner(System.in);
    System.out.print("Ingrese codigo a incrementar su stock: ");
    int cod= in.nextInt();
    System.out.print("Ingrese cantidad a incrementar: ");
    int stock = in.nextInt();
    int i=0;
    in.close();
    while((v[i].getCodigo() !=cod) && (cant<i)){
        i++;
    }
    if(v[i].getCodigo() == cod){
        v[i].incrementarStock(stock);
        return true;
    }
    else {
        return false;
    }
}
}