public class Producto{
    private int codigo;
    private String nombre;
    private String descripcion;
    private String marca;
    private int unidades;
    
    public Producto(int unCodigo, String unNombre, String unaDescripcion, String unaMarca, int unidad){
        codigo=unCodigo;
        nombre=unNombre;
        descripcion=unaDescripcion;
        marca=unaMarca;
        unidades=unidad;
    }
    
    public Producto(){
        
    }
    
    public int getCodigo(){
        return codigo;
    }
    
    public String getNombre(){
        return nombre;
    }
    public String getDescripcion(){
        return descripcion;
    }
    
    public String getMarca(){
        return marca;
    }
    
    public int getUnidades(){
        return unidades;
    }
    
    public void setCodigo(int unCodigo){
        codigo=unCodigo;
    }
    
    public void setNombre(String unNombre){
        nombre=unNombre;
    }
    
    public void setDescripcion(String unaDescripcion){
        descripcion=unaDescripcion;
    }
    
    public void setMarca(String unaMarca){
        marca=unaMarca;
    }
    
    public void setUnidades(int unidad){
        unidades=unidad;
    }
    
    public void incrementarStock (int unidad){
        unidades=unidades+unidad;
    }
    
}