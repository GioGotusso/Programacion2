import java.util.Scanner;
public class P3E3{
public static void main (String [] args){
    Scanner in = new Scanner(System.in);
    System.out.print("Ingrese nombre del entrenador: ");
    String nombre = in.next();
    System.out.print("Ingrese sueldo del entrenador: ");
    double sueldo = in.nextDouble();
    System.out.print("Ingrese campeonatos del entrenador: ");
    int camp = in.nextInt();
    Entrenador e = new Entrenador(nombre,sueldo,camp);
    in.close();
}
}