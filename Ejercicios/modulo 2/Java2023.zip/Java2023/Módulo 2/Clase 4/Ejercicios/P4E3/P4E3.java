import java.util.Scanner;
public class P4E3{
public static void main(String[]args){
    Scanner in = new Scanner(System.in);
    Micro m = new Micro("ABC123","Mar del plata","5:00 am");
    System.out.print("Ingrese numero de asiento: ");
    int num=in.nextInt();
    while((num!=-1)&&(m.microLleno()==false)){
        if(m.validarAsiento(num)){
            if(m.estadoAsiento(num)==false){
                System.out.println(m.ocuparAsiento(num));
            }
            else{
                System.out.println("El asiento seleccionado esta ocupado");
                System.out.println("El siguiente asiento disponible es el "+m.asientoLibre());
            }
        }
        else{
            System.out.println("El numero de asiento ingresado no es valido, ingrese uno dentro del rango 0-19");
        }
        if(m.microLleno()==false){
            System.out.println();
            System.out.print("Ingrese numero de asiento: ");
            num=in.nextInt();
        }   
    }
    System.out.println();
    System.out.println("La cantidad de asientos ocupados fue de "+m.asientosOcupados());
}
}