import java.util.Scanner;
public class P4E1{
public static void main (String[]args){
    Scanner in = new Scanner(System.in);
    System.out.print("Ingrese lado 1: ");
    double lado1=in.nextDouble();
    System.out.print("Ingrese lado 2: ");
    double lado2=in.nextDouble();
    System.out.print("Ingrese lado 3: ");
    double lado3=in.nextDouble();
    System.out.print("Ingrese color del relleno: ");
    String colorR=in.next();
    System.out.print("Ingrese color de lineas: ");
    String colorL=in.next();
    Triangulo t = new Triangulo(lado1,lado2,lado3,colorR,colorL);
    System.out.println();
    System.out.print("Ingrese lado 1: ");
    lado1=in.nextDouble();
    System.out.print("Ingrese lado 2: ");
    lado2=in.nextDouble();
    System.out.print("Ingrese lado 3: ");
    lado3=in.nextDouble();
    System.out.print("Ingrese color del relleno: ");
    colorR=in.next();
    System.out.print("Ingrese color de lineas: ");
    colorL=in.next();
    Triangulo t1= new Triangulo();
    t1.setLado1(lado1);
    t1.setLado2(lado2);
    t1.setLado3(lado3);
    t1.setColorRelleno(colorR);
    t1.setColorLinea(colorL);
    
    in.close();
}
}