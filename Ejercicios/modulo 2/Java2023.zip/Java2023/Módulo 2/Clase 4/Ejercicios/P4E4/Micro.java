public class Micro{
    private String patente;
    private String destino;
    private String hora;
    private boolean[] asientos= new boolean[20];
    private int cant;
    
    public Micro(){
        
    }
    
    public Micro(String patente, String destino, String hora){
        this.patente=patente;
        this.destino=destino;
        this.hora=hora;
        cant=0;
        int i;
        for(i=0;i<20;i++){
            asientos[i]=false;
        }
        
    }
    
    public void setPatente(String patente){
        this.patente=patente;
    }
    
    public void setDestino(String destino){
        this.destino=destino;
    }
    
    public void setHora(String hora){
        this.hora=hora;
    }
    
    public String getPatente(){
        return patente;
    }
    
    public String getDestino(){
        return destino;
    }
    
    public String getHora(){
        return hora;
    }
    
    public int asientosOcupados(){
        return cant;
    }
    
    public boolean microLleno(){
        if(cant==20){
          return true;  
        }
        else{
            return false;
        }
    }
    
    public boolean validarAsiento(int asiento){
        if((asiento>=0)&&(asiento<=19)){
            return true;
        }
        else{
            return false;
        }
    }
    
    public boolean estadoAsiento(int asiento){
        if(asientos[asiento]){
            return true;
        }
        else{
            return false;
        }
    }
    
    public String ocuparAsiento(int asiento){
        asientos[asiento]=true;
        cant++;
        return ("El asiento se ha ocupado con exito");
    }
    
    public void liberarAsiento(int asiento){
        asientos[asiento]=false;
        cant--;
    }
    
    public int asientoLibre(){
        int i=0;
        while(asientos[i]){
            i++;   
        }
        if(asientos[i]==false){
            return i;
        }
        else{
            return -1;
        }
    }
    
    
    
}