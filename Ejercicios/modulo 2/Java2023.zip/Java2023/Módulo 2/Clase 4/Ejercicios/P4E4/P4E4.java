import java.util.Scanner;
public class P4E4{
public static void main (String[]args){
    Scanner in = new Scanner (System.in);
    Flota f = new Flota();
    String destino=".";
    String hora= ".";
    System.out.print("Ingrese patente del micro: ");
    String patente= in.next();
    if(!(patente.equals("ZZZ000"))){
        in.nextLine();
        System.out.print("Ingrese destino: ");
        destino=in.nextLine();
        System.out.print("Ingrese hora: ");
        hora=in.nextLine();
    }
    while((!(patente.equals("ZZZ000")))&&(f.estaCompleta()==false)){
        Micro m = new Micro(patente,destino,hora);
        f.agregarMicro(m);
        System.out.print("Ingrese patente del micro: ");
        patente= in.next();
        if(!(patente.equals("ZZZ000"))){
            in.nextLine();
            System.out.print("Ingrese destino: ");
            destino=in.nextLine();
            System.out.print("Ingrese hora: ");
            hora=in.nextLine();
        }
    }
    System.out.println();
    System.out.print("Ingrese patente a buscar: ");
    patente=in.next();
    if(f.buscarMicroPorPatente(patente)!=null){
        f.eliminarMicro(patente);
        System.out.println("El micro fue eliminado de la flota");
    }
    else{
        System.out.println("La flota no cuenta con ningun micro con patente "+patente);
    }
    System.out.println();
    System.out.print("Ingrese destino a buscar: ");
    destino=in.next();
    Micro microDestino=f.buscarMicroPorDestino(destino);
    if(microDestino!=null){
        System.out.println("El micro que se dirige a "+destino+" tiene la patente "+microDestino.getPatente()+" y su horario es de "+microDestino.getHora());
    }
    else{
        System.out.println("La flota no cuenta con ningun micro que vaya a "+destino);
    }
    
    
    
    
    
    
    in.close();
}
}