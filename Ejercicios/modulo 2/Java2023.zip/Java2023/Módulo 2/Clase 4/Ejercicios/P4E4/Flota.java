public class Flota{
    private Micro[] micros;
    private int cantMicros;
    
    public Flota(){
        micros=new Micro [15];
        cantMicros=0;
    } 
    
    public boolean estaCompleta(){
        if(cantMicros==14){
            return true;
        }
        else{
            return false;
        }
    }
    
    public void agregarMicro(Micro m){
        micros[cantMicros]=m;
        cantMicros++;
    }
    
    public void eliminarMicro(String patente){
        int i=0;
        int j;
        while((!(micros[i].getPatente().equals(patente)))&&(i<14)){
            i++;
        }
        if(micros[i].getPatente().equals(patente)){
            for(j=i;j<cantMicros;j++){
                micros[j]=micros[j+1];
            }
            cantMicros--;
            
        }
    }
    
    public Micro buscarMicroPorPatente(String patente){
        int i=0;
        while((i<cantMicros)&&(!(micros[i].getPatente().equals(patente)))){
            i++;
        }
        if(micros[i].getPatente().equals(patente)){
            return micros[i];
        }
        else{
            return null;
        }
    }
    
    public Micro buscarMicroPorDestino(String destino){
        int i=0;
        while((i<cantMicros)&&(!(micros[i].getDestino().equals(destino)))){
            i++;
        }
        if(micros[i].getDestino().equals(destino)){
            return micros[i];
        }
        else{
            return null;
        }
    }
}


