public class Jugador extends Empleado{ 
    private int partJugados;
    private int goles;
    
    public Jugador(String nombre, int dni, int edad, double sueldo, int partidos, int unGol){
        super(nombre,dni,edad,sueldo);
        partJugados = partidos;
        goles=unGol;
    }
    
    public Jugador(){
     
    }

    public int getPartidos(){
        return partJugados;
    }
    
    public int getGoles(){
        return goles;
    }
    
    public void setPartidos(int partidos){
        partJugados=partidos;
    }
    
    public void setGoles(int unGol){
        goles=unGol;
    }
    
    public double calcularSueldoACobrar(){
        double s=super.getSueldo();
        if((goles/partJugados)>0.5){
            return (s+s);
        }
        else{
            return s;
        }
    }
    
    
}