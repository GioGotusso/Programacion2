import java.util.Scanner;
public class P5E1{
public static void main (String[]args){
    Scanner in = new Scanner(System.in);
    System.out.print("Ingrese nombre del jugador: ");
    String nombre=in.next();
    System.out.print("Ingrese DNI del jugador: ");
    int dni=in.nextInt();
    System.out.print("Ingrese edad del jugador: ");
    int edad = in.nextInt();
    System.out.print("Ingrese sueldo basico del jugador: ");
    double sueldo = in.nextDouble();
    System.out.print("Ingrese cantidad de partidos jugados: ");
    int cant = in.nextInt();
    System.out.print("Ingrese cantidad de goles: ");
    int goles = in.nextInt();
    Jugador j = new Jugador(nombre,dni,edad,sueldo,cant,goles);
    System.out.println();
    System.out.print("Ingrese nombre del entrenador: ");
    nombre=in.next();
    System.out.print("Ingrese DNI del entrenador: ");
    dni=in.nextInt();
    System.out.print("Ingrese edad del entrenador: ");
    edad=in.nextInt();
    System.out.print("Ingrese sueldo basico del entrenador: ");
    sueldo=in.nextDouble();
    System.out.print("Ingrese campeonatos ganados del entrenador: ");
    cant=in.nextInt();
    Entrenador e = new Entrenador(nombre,dni,edad,sueldo,cant);
    System.out.println();
    System.out.println("JUGADOR: ");
    System.out.println("Nombre: "+j.getNombre());
    System.out.println("DNI: "+j.getDni());
    System.out.println("Edad: "+j.getEdad());
    System.out.println("Sueldo basico: "+j.getSueldo());
    System.out.println("Partidos jugados: "+j.getPartidos());
    System.out.println("Goles: "+j.getGoles());
    System.out.println("Sueldo a cobrar: "+j.calcularSueldoACobrar());
    System.out.println(j.toString());
    System.out.println();
    System.out.println("ENTRENADOR: ");
    System.out.println("Nombre: "+e.getNombre());
    System.out.println("DNI: "+e.getDni());
    System.out.println("Edad: "+e.getEdad());
    System.out.println("Sueldo basico: "+e.getSueldo());
    System.out.println("Campeonatos: "+e.getCampeonatos());
    System.out.println("Sueldo a cobrar: "+e.calcularSueldoACobrar());
    System.out.println(e.toString());
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    in.close();
}
}