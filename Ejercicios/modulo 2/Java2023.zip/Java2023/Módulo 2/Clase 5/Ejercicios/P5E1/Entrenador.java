public class Entrenador extends Empleado{
    private int campeonatos; 
    
    public Entrenador(String nombre, int dni, int edad, double sueldo, int campeonatos){
        super(nombre,dni,edad,sueldo);
        this.campeonatos = campeonatos; 
    }
    
    public Entrenador(){
     
    }


    public int getCampeonatos() {
        return campeonatos;
    }

    public void setCampeonatos(int unCampeonato) {
        campeonatos = unCampeonato;
    }

    public double calcularSueldoACobrar(){
        double s=super.getSueldo();
        if((campeonatos>=1) && (campeonatos<=4)){
            return (s+5000);
        }
        else{
            if((campeonatos>=5) && (campeonatos<=10)){
                return (s+30000);
            }
            else{
                if(campeonatos>10){
                    return (s+50000);
                }
                else{
                    return s;
                }
            }
        }
    }  
}