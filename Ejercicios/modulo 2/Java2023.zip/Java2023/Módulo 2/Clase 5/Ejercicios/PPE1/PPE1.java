import java.util.Scanner;
public class PPE1{
public static void main (String[]args){
    Scanner in = new Scanner(System.in);
    Dibujo d = new Dibujo("Gonzalo","la casa soleada",4);
    Triangulo t = new Triangulo(71,71,71,"Rojo","Negro",new Punto(56,100));
    Circulo c = new Circulo (32,"Naranja","Negro",new Punto(149,82));
    Cuadrado c1 = new Cuadrado (71,"Amarillo","Negro",new Punto(56,156));
    Cuadrado c2 = new Cuadrado (26,"Marron","Negro",new Punto(56,177));
    d.añadirFigura(c);
    d.añadirFigura(c1);
    d.añadirFigura(c2);
    d.añadirFigura(t);
    System.out.println(d.toString());
    d.mostrar();
    in.close();
}
}