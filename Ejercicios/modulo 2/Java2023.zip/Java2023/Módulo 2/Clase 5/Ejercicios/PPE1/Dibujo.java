public class Dibujo{
    private String autor;
    private String titulo;
    private int dimL=0;
    private int cant;
    private Figura[] v;    
    public Dibujo(String autor, String titulo, int cant){
        this.autor=autor;
        this.titulo=titulo;
        this.cant=cant;
        v= new Figura[cant];
    }
    
    public Dibujo(){
        
    }
    
    public void setTitulo(String titulo){
        this.titulo= titulo;
    }
    
    public void setAutor(String autor){
        this.autor=autor;
    }
    
    public void setCantFiguras(int cant){
        this.cant=cant;
    }
    
    public String getTitulo(){
        return titulo;
    }
    
    public String getAutor(){
        return autor;
    }
    
    public int getCantFiguras(){
        return cant;
    }
    
    public void añadirFigura(Figura f){
        if(dimL<cant){
            v[dimL]=f;
            dimL++;
        }
    }
    
    public boolean estaLleno(){
        if(dimL == cant){
            return true;
        }
        else{
            return false;
        }
    }
    
    @Override
    public String toString(){
        return (autor +" "+ titulo);
    }
    
    
    public void mostrar(){
        int i;
        
        for(i=0;i<cant;i++){
            v[i].dibujar();
        }
    }

}