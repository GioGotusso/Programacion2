import java.util.Scanner;
public class P1E7{
public static void main (String[]args){
    Scanner in = new Scanner(System.in);
    String [] op = new String[5];
    int [] vector = new int[5];
    int i;
    int max=0;
    int ind=-1;
        for (i=0;i<5;i++){
        vector[i]=0;
    }
    
    System.out.println("Ingrese operación a realizar: ");
    System.out.println("-----------------------------------");
    System.out.println("-0- cobro de cheque");
    System.out.println("-1- depósito/extracción en cuenta");
    System.out.println("-2- pago de impuestos o servicios");
    System.out.println("-3- cobro de jubilación");    
    System.out.println("-4- cobro de planes");    
    System.out.println("-----------------------------------");
    int operacion = in.nextInt();
    
    while (operacion !=999){
        switch(operacion){
            case 0: vector[operacion]++;
                    break;
            case 1: vector[operacion]++;
                    break;
            case 2: vector[operacion]++;
                    break;
            case 3: vector[operacion]++;
                    break;
            case 4: vector[operacion]++;
                    break;
        }
            System.out.print("Ingrese operación a realizar: ");
            operacion = in.nextInt();
    
    }
    
    for (i=0;i<5;i++){
        System.out.println("La operacion "+i+" tuvo "+ vector[i] +" personas atendidas");
        if(vector[i] > max){
            max=vector[i];
            ind=i;
        }
    }
    
    
    switch (ind){
        case 0: System.out.println("La operación mas solicitada fue la numero "+ind+": cobro de cheque");
                break;
        case 1: System.out.println("La operación mas solicitada fue la numero "+ind+": depósito/extracción en cuenta");
                break;
        case 2: System.out.println("La operación mas solicitada fue la numero "+ind+": pago de impuestos o servicios");
                break;
        case 3: System.out.println("La operación mas solicitada fue la numero "+ind+": cobro de jubilación");
                break;
        case 4: System.out.println("La operación mas solicitada fue la numero "+ind+": cobro de planes");
                break;
    }
    
    
    in.close();
}
}