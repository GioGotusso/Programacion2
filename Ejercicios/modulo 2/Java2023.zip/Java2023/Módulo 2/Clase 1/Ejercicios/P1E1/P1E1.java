import java.util.Scanner;
public class P1E1{
 public static void main(String[] args){
     Scanner in = new Scanner(System.in);
     System.out.print("Ingrese primer lado: ");
     double a = in.nextDouble();
     System.out.print("Ingrese segundo lado: ");
     double b = in.nextDouble();
     System.out.print("Ingrese tercer lado: ");
     double c = in.nextDouble();
     in.close();
     double perimetro = a+b+c;
     if ((a<b+c) && (b<a+c) && (c<a+b)){
         System.out.println("El perimetro del triangulo es " + perimetro);
        }
    else {      
        System.out.println("El triangulo no es valido ");}
    }
}
    
     