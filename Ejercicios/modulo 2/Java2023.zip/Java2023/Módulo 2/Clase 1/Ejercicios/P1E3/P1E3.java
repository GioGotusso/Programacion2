import java.util.Scanner;
public class P1E3{ 
public static void main (String[]args){
    Scanner in =new Scanner(System.in);
    System.out.print("Ingrese numero: ");
    int N =in.nextInt();
    int i;
    int factorial=N;
    for (i=N; i>1; i--){
        factorial=factorial*(i-1);
    }
    in.close(); 
    System.out.println("El factorial de "+N+" es "+factorial);
        
    
   
}
}