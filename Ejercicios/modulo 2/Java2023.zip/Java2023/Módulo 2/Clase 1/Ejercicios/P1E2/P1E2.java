import java.util.Scanner;
public class P1E2{
public static void main(String[]args){
  Scanner in = new Scanner(System.in);  
      int pasan = 0; 
      int autos = 0;
      System.out.print("Ingrese patente: ");
      int patente = in.nextInt();
      while (patente != 0) {
          autos++;
          if(patente %2 ==0){
              pasan++;
              System.out.println("El auto con patente "+patente+" tiene permitido el paso ");
          }
          else {
              System.out.println("El auto con patente "+patente+" no tiene permitido el paso ");
          }
        System.out.print("Ingrese patente: ");
         patente = in.nextInt();
      }
  in.close();
  double porcentaje = pasan*100/autos;
  System.out.print("El porcentaje de autos que pasaron fue de " + porcentaje+ "%");
}
}