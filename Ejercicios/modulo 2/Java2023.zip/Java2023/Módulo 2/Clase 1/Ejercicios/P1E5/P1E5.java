import java.util.Scanner;
public class P1E5{
public static void main (String[] args){
    Scanner in = new Scanner(System.in);
    double [] alturas = new double[15];
    int i;
    int j;
    int cont=0;
    double promedio=0;
    for(i=0; i<14; i++){
        System.out.print("Ingrese altura del jugador");
        alturas[i]=in.nextDouble();
        promedio=promedio+alturas[i];
    }
    in.close();
    promedio=promedio/15;
    for(j=0; j<14; j++){
        if(alturas[i]>promedio){
            cont++;
    }
}
    System.out.println("La altura promedio es de "+promedio);
    System.out.println("La cantidad de jugadores con altura mayor a la promedio es de "+cont);
}
}