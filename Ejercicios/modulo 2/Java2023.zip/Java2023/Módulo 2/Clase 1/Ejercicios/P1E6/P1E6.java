import java.util.Scanner;
public class P1E6{
public static void main (String[]args){
    Scanner in = new Scanner(System.in);
    int [][] matriz= new int[10][10];
    int i,j;
    int pos=-2;
    for (i=0;i<10;i++){
        for(j=0;j<10;j++){
            matriz[i][j]=pos+2;
            pos=pos+2;
        }
    }
    for (i=0;i<10;i++){
        for(j=0;j<10;j++){
            System.out.println(matriz[i][j]);
        }
    }
    int suma=0;
    for (i=3;i<9;i++){
        for(j=1;j<3;j++){
            suma=suma+matriz[i][j];
            }
        }
    int [] vector= new int[10];
    for (j=0;j<10;j++){
        for(i=0;i<10;i++){
            vector[j]=vector[j]+matriz[i][j];
            
        }
    }
    for (i=0;i<10;i++){
        System.out.println(vector[i]);
    }
    System.out.print("Ingrese numero a buscar: ");
    int num = in.nextInt();
    int fil=0;
    int col=0;
    boolean ok=false;
    for (i=0;i<10;i++){
        for(j=0;j<10;j++){
           if(matriz[i][j]==num){
               ok=true;
               fil=i;
               col=j;
           }
            }
    }
    if(ok){
    System.out.print("El numero "+num+" se encuentra en la fila "+fil+" y la columna "+col);
    }
    else{
        System.out.print("No se encontro el elemento");
    }

    in.close();
}
}