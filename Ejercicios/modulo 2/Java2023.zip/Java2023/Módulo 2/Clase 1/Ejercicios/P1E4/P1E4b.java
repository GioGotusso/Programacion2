public class P1E4b{
public static void main(String[]args){ 
    int i;
    int factorial=1;
    for(i=1; i<=9; i++){
        factorial=factorial*i;
        if(i%2 !=0){
            System.out.println("El factorial de "+i+" es "+factorial);
        }
    }
}
}