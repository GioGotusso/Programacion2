public class P1E4{
public static void main(String[]args){
    int i;
    int factorial=1;
    for(i=1; i<=9; i++){
        factorial=factorial*i;
        System.out.println("El factorial de "+i+" es "+factorial);
    }
}
}