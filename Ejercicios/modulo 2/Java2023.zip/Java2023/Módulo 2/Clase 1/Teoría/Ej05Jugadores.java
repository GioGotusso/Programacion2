
/**
 * Write a description of class Programa here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ej05Jugadores
{
    /**
     * Método main
     * 
     */
    public static void main(String[] args)
    {
        //Paso 1: Declarar la variable vector de alturas
        
        //Paso 2: Declarar indice y promedio (iniciarlo)
        
        //Paso 3: Declarar y crear el scanner
        
        //Paso 4: Crear el vector para 15 valores
        
        //Paso 5: Ingresar 15 numeros, cargarlos en el vector, ir calculando la suma
        
        //Paso 6: Calcular el promedio
        
        //Paso 7: Recorrer el vector, contar los números que son mayores que el promedio
    }
}
