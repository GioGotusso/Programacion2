import java.util.Scanner;
public class P2E6{
public static void main (String[] args){
    Scanner in = new Scanner(System.in);
    String [] vector = new String[10];
    int i;
    for (i=0;i<10;i++){
        System.out.print("Ingrese string a cargar: ");
        String s = in.next();
        vector[i]=s;
    }
    for (i=0;i<10;i++){
        System.out.print(vector[i].charAt(0));
    }
    in.close();
}
}