import java.util.Scanner;
public class P2E4{
public static void main (String[]args){
    Scanner in = new Scanner (System.in);
    Partido [] vector = new Partido[5];
    int i;
    for(i=0;i<5;i++){
        Partido p = new Partido();
        System.out.print("Ingrese equipo local: ");
        String local = in.next();
        p.setLocal(local);
        System.out.print("Ingrese equipo visitante: ");
        String visitante = in.next();
        p.setVisitante(visitante);
        System.out.print("Ingrese goles del equipo local: ");
        int gLocal = in.nextInt();
        p.setGolesLocal(gLocal);
        System.out.print("Ingrese goles del equipo visitante: ");
        int gVisitante = in.nextInt();
        p.setGolesVisitante(gVisitante);
        vector[i]=p;
    }
    System.out.println("La cantidad de partidos ganados por River fue de "+river(vector));
    System.out.println("La cantidad de goles que metió Boca fue de "+boca(vector));
    System.out.println("El porcentaje de empates es de "+empate(vector)+"%");
    in.close();
}
public static int river (Partido[] v){
    int i;
    int cont=0;
    for (i=0;i<5;i++){
        if(v[i].hayGanador()){
            if(v[i].getGanador().equals("River")){
                cont++;
            }
        }
    }
    return cont;
}
public static int boca (Partido [] v){
    int i;
    int cont=0;
    for(i=0;i<5;i++){   
        if(v[i].getLocal().equals("Boca")){
            cont=cont+v[i].getGolesLocal();
        }
        else{
            if (v[i].getVisitante().equals("Boca")){
                cont=cont+v[i].getGolesVisitante();
        }
        }
    }
    return cont;
}
public static double empate (Partido[] v){
    int i;
    double porcentaje=0;
    for (i=0;i<5;i++){
        if(v[i].hayEmpate()){
            porcentaje++;
        }
    }
    porcentaje=porcentaje*100/5;
    return porcentaje;
}
}