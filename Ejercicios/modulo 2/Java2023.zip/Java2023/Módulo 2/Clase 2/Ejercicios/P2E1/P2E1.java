import java.util.Scanner;
public class P2E1{
public static void main (String[]args){
    Scanner in = new Scanner(System.in);
    System.out.print("Ingrese nombre: ");
    String nombre = in.next();
    System.out.print("Ingrese DNI: ");
    int dni = in.nextInt();
    System.out.print("Ingrese edad: ");
    int edad = in.nextInt();
    Persona p = new Persona(nombre,dni,edad);
    System.out.println(p.toString());
    in.close();
}
}