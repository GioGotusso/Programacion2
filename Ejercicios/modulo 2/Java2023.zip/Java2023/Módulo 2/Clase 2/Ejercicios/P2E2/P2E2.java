import java.util.Scanner;
public class P2E2{
public static void main(String[]args){
    Scanner in = new Scanner (System.in);
    Persona [] vector = new Persona[15];
    int i;
    for(i=0;i<15;i++){
        System.out.print("Ingrese nombre: ");
        String nombre = in.next();
        System.out.print("Ingrese DNI: ");
        int dni = in.nextInt();
        System.out.print("Ingrese edad: ");
        int edad = in.nextInt();
        vector[i]= new Persona(nombre,dni,edad);
    
    }
    for (i=0;i<15;i++){
        System.out.println(vector[i].toString());
    }
    in.close();
    System.out.println("La cantidad de personas mayores a 65 es de " + mayor65(vector));
    
    System.out.println(menor(vector).toString());
}
public static int mayor65(Persona [] v){
    int i;
    int cont=0;
    for (i=0;i<15;i++){
        if(v[i].getEdad() > 65){
            cont++;
        }
       }
    return cont;
    }
public static Persona menor(Persona [] v){
    int i;
    int min=99999999;
    Persona p = new Persona();
    for (i=0;i<15;i++){
        if(v[i].getDNI() < min){
            min=v[i].getDNI();
            p=v[i];
        }
    }
    return p;
    
}











}