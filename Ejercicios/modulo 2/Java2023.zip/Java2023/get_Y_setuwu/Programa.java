import java.util.Scanner;
public class Programa{
    public static void main(String [] args){
        Scanner in= new Scanner(System.in);
        objet [] vector= new objet [1000];
        int dim=0;
        System.out.println("defini parar(1: sige/ 0: termina)");
        int parar= in.nextInt();
        while(parar != 0){
            vector[dim]= crearobjeto(in);
            dim++;
            System.out.println("parar(1: sige/ 0: termina)");
            parar= in.nextInt();
        }
        imprimir(vector, dim);
    }
    
    public static objet crearobjeto(Scanner in){
        System.out.println("tipo");
        String t= in.next();
        System.out.println("nombre");
        String n= in.next();
        objet o= new objet(t,n);
        return o;
    }
    
    public static void imprimir(objet [] v, int d){
        for(int i=0; i<d; i++){
            System.out.println("    public "+v[i].getTipo()+" get"+v[i].getNombre()+"(){");
            System.out.println("    return "+v[i].getNombre()+";");
            System.out.println("    }");
            System.out.println("    public void set"+v[i].getNombre()+"("+v[i].getTipo()+" "+v[i].getNombre()+"){");
            System.out.println("    this."+v[i].getNombre()+"= "+v[i].getNombre()+";");
            System.out.println("    }");
        }   
        }
    }    
