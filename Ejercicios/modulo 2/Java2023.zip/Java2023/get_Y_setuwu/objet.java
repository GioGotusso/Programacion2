public class objet{
    private String tipo;
    private String nombre;
    
    public objet(){
        
    }
    public objet(String tipo, String nombre){
        this.tipo= tipo;
        this.nombre=nombre;
    }
    
    public String getTipo(){
        return tipo;
    }
    public String getNombre(){
        return nombre;
    }
    
}
