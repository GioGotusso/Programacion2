
public abstract class Inmuebles
{
    private String Cod;
    private String Direc;
    private double metros2;
    private Propietario p;
    public Inmuebles(){
        
    }
    public Inmuebles(String Cod,String Direc,double metros2,Propietario p){
        this.Cod=Cod;
        this.Direc=Direc;
        this.metros2=metros2;
        this.p=p;
    }
    public String getCod(){
        return Cod;
    }
    public void setCod(String Cod){
        this.Cod=Cod;
    }
    public String getDirec(){
        return Direc;
    }
    public void setDirec(String Direc){
        this.Direc=Direc;
    }
    public double getmetros2(){
        return metros2;
    }
    public void setmetros2(double metros2){
        this.metros2=metros2;
    }
    public abstract double calcValor();
    public abstract double calcHonor();
    public abstract double calcAFIP();
    public abstract String toString();
}