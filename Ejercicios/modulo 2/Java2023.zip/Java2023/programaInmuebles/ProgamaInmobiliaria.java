import java.util.Scanner;
public class ProgamaInmobiliaria
{
   public static void main(String[] args){
       Scanner in=new Scanner(System.in);
       Inmuebles[] I=new Inmuebles[5];
       String Cod;
       String Direc;
       double metros2;
       int DNI;
       String Nombre;
       String Apellido;
       String Contacto;
       double lote;
       double expen;
       boolean encargado;
       for (int i=0; i<2; i++){
           System.out.println("Ingrese casa o depto");
           String Es=in.next();
           int x=0;
           while (x!=-1){
               if (Es.equals("casa")){
                   System.out.println("Ingrese datos de la casa");
                   System.out.println("Ingrese Codigo del inmueble");
                   Cod=in.next();
                   System.out.println("Ingrese direccion de la casa");
                   Direc=in.nextLine();
                   Direc=in.nextLine();
                   System.out.println("Ingrese cantidad de metros cuadrados");
                   metros2=in.nextDouble();
                   System.out.println("Ingrese tamaño del lote");
                   lote=in.nextDouble();
                   System.out.println("Ingrese datos del Propietario(DNI,NOmbre,Apellido,Mail)");
                   DNI=in.nextInt();
                   Nombre=in.next();
                   Apellido=in.next();
                   Contacto=in.next();
                   Propietario p=new Propietario(DNI,Nombre,Apellido,Contacto);
                   Casa C=new Casa(Cod,Direc,metros2,p,lote);
                   I[i]=C;
                   x=-1;
               }
               else
                   if(Es.equals("depto")){
                       System.out.println("Ingrese datos del depto");
                       System.out.println("Ingrese Codigo del inmueble");
                       Cod=in.next();
                       System.out.println("Ingrese direccion del depto");
                       Direc=in.nextLine();
                       Direc=in.nextLine();
                       System.out.println("Ingrese cantidad de metros cuadrados");
                       metros2=in.nextDouble();
                       System.out.println("Ingrese valor de las expensas");
                       expen=in.nextDouble();
                       System.out.println("Ingrese si tiene encargado de consorcio(si/no)");
                       String con=in.next();
                       if(con.equals("si")){
                           encargado=true;
                       }
                        else{
                           encargado=false;
                       }
                       System.out.println("Ingrese datos del Propietario(DNI,NOmbre,Apellido,Mail)");
                       DNI=in.nextInt();
                       Nombre=in.next();
                       Apellido=in.next();
                       Contacto=in.next();
                       Propietario p=new Propietario(DNI,Nombre,Apellido,Contacto);
                       Depto D=new Depto(Cod,Direc,metros2,p,expen,encargado);
                       I[i]=D;
                       x=-1;
                    }
                   else{
                      System.out.println("Tipo de inmueble incorrecto por favor ingrese casa o depto"); 
                      Es=in.next();
                   }
                }    
       }
       for (int i=0;i<2;i++){
           System.out.println("inmueble numero "+(i++));
           System.out.println(I[i].toString());
       }
   }
}
