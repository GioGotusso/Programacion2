
public class Casa extends Inmuebles
{
    private double lote;
    public Casa(){
        
    }
    public Casa(String Cod,String Direc,double metros2,Propietario p,double lote){
        super(Cod, Direc,metros2,p);
        this.lote=lote;
    }
    public double getlote(){
        return lote;
    }
    public void setlote(double lote){
        this.lote=lote;
    }
    public double calcValor(){
        double aux;
        aux=(lote*1000)+(getmetros2()*1500);
        return aux;
    }
    public double calcHonor(){
        double aux;
        aux=(this.calcValor()*0.035);
        return aux;
    }
    public double calcAFIP(){
        AFIP a=new AFIP();
        double aux;
        aux=a.valorFiscalAEscriturar(this.calcValor()*0.1);
        return aux;
    }
    public String toString(){
        return ("Valor Propiedad (en U$D):"+this.calcValor()+"\nHonorarios Inmobiliaria (en U$D):"+this.calcHonor()+"\nHonorarios Escritura (en crocantes):"+this.calcAFIP());
    }
}