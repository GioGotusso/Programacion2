public class Propietario
{
    private int DNI;
    private String Nombre;
    private String Apellido;
    private String Contacto;
    public Propietario(){
    }
    public Propietario(int DNI,String Nombre,String Apellido,String Contacto){
        this.DNI=DNI;
        this.Nombre=Nombre;
        this.Apellido=Apellido;
        this.Contacto=Contacto;
    }
    public int getDNI(){
        return DNI;
    }
    public void setDNI(int DNI){
        this.DNI=DNI;
    }
    public String getNombre(){
        return Nombre;
    }
    public void setNombre(String Nombre){
        this.Nombre=Nombre;
    }
    public String getApellido(){
        return Apellido;
    }
    public void setApellido(String Apellido){
        this.Apellido=Apellido;
    }
    public String getContacto(){
        return Contacto;
    }
    public void setContacto(String Contacto){
        this.Contacto=Contacto;
    }
}