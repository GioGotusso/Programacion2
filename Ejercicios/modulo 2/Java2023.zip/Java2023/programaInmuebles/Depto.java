public class Depto extends Inmuebles
{
    private double expen;
    private boolean encargado;
    public Depto(){
        
    }
    public Depto(String Cod,String Direc,double metros2,Propietario p,double expen,boolean encargado){
        super(Cod,Direc,metros2,p);
        this.expen=expen;
        this.encargado=encargado;
    }
    public double getexpen(){
        return expen;
    }
    public void setexpen(double expen){
        this.expen=expen;
    }
    public boolean getencargado(){
        return encargado;
    }
    public void setencargado(boolean encaragado){
        this.encargado=encargado;
    }
    public double calcValor(){
        double aux;
        aux=(getmetros2()*2000)+(expen*12);
        return aux;
    }
    public double calcHonor(){
        double aux;
        aux=(this.calcValor()*0.03);
        return aux;
    }
    public double calcAFIP(){
        AFIP a=new AFIP();
        double aux;
        aux=a.valorFiscalAEscriturar(this.calcValor()*0.085);
        return aux;
    }
    public String toString(){
        return ("Valor Propiedad (en U$D):"+this.calcValor()+"\nHonorarios Inmobiliaria (en U$D):"+this.calcHonor()+"\nHonorarios Escritura (en crocantes):"+this.calcAFIP());
    }
}