
/**
 * Write a description of class AFIP here.
 * 
 * @author (Leandro Romanut) 
 * @version (1.0)
 */
public class AFIP
{
     
    public AFIP()
    {

    }

    /**
     * Método para obtener el valor fiscal por el cuál se va a escriturar una propiedad
     * 
     * @param monto de la operación en dólares
     * @return monto de la operación en pesos
     */
    public static double valorFiscalAEscriturar(double monto)
    {
        return ((monto/2)*120);
    }
}
