public class constructorMicros {
    
   private String patente;
   private String destino;
   private String horaSalida;
   private boolean[]Asientos;

    }