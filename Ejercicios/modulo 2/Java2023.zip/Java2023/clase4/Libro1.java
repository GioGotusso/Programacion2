public class Libro1 {
   private String titulo;
   private int paginas;
   private String editorial;
   private int AñoEdicion;
   private String idioma;
   private String primerAutor; 
   private String ISBN; 
   private double precio; /*en dolares*/
   private int cantidadEnStock;
    
 
    public Libro1(  String unTitulo, int unaCantidadPaginas,  String unaEditorial, 
    int unAñoEdicion, String unIdioma,  String unPrimerAutor, String unISBN, double unPrecio,  int unaCantidadStock){
         titulo = unTitulo;
         paginas = unaCantidadPaginas;
         editorial = unaEditorial; 
         AñoEdicion= unAñoEdicion;
         idioma= unIdioma; 
         primerAutor = unPrimerAutor;
         ISBN =  unISBN;
         precio = unPrecio;
         cantidadEnStock = unaCantidadStock; 
    }
    
    public Libro1(  String unTitulo, int unaCantidadPaginas,  String unaEditorial, String unPrimerAutor, String unISBN, double unPrecio,  int unaCantidadStock){
         titulo = unTitulo;
         paginas = unaCantidadPaginas;
         editorial = unaEditorial; 
         AñoEdicion= 2015;
         idioma= "Ingles"; 
         primerAutor = unPrimerAutor;
         ISBN =  unISBN;
         precio = unPrecio;
         cantidadEnStock = unaCantidadStock; 
    }
    
    public Libro1(){
   
    }
        
    public String getTitulo(){
        return titulo;
    }
    public int getPaginas(){
        return paginas;
    }
    public String getEditorial(){
        return editorial;
    }
    public int getAñoEdicion(){
        return AñoEdicion;
    }
    public String getIdioma(){
        return idioma;
    }
    public String getPrimerAutor(){
        return primerAutor;
    } 
    public String getISBN(){
        return ISBN;
    } 
    public double getPrecio(){
        return precio;
    }
    public int getCantidadEnStock(){
        return cantidadEnStock;
    }
    
    public void setTitulo(String unTitulo){
        titulo = unTitulo;
    }
    public void setPaginas(int unaCantidad){
        paginas = unaCantidad;
    }
    public void setEditorial(String unaEditorial){
         editorial = unaEditorial;
    }
    public void setAñoEdicion(int unAño){
         AñoEdicion = unAño;
    }
    public void setIdioma(String unIdioma){
         idioma=unIdioma;
    }
    public void setPrimerAutor(String unPrimerAutor){
         primerAutor=unPrimerAutor;
    } 
    public void setISBN(String unISBN){
         ISBN=unISBN;
    } 
    public void setPrecio(double unPrecio){
         precio=unPrecio;
    }
    public void setCantidadEnStock(int unaCantidad){
         cantidadEnStock=unaCantidad;
    }
    
   @Override
    public String toString(){
       return (titulo + " por " + primerAutor + " - " + AñoEdicion + " - " + " ISBN: " + ISBN );
    }
        
}
