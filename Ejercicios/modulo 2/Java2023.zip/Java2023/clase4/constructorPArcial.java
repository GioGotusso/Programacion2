public class constructorPArcial
{
   private String patente;
   private String destino;
   private String hora;
   private int[]vec;
   private 
   public constructorPArcial(){
       
    }
