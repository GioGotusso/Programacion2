import java.util.Scanner;
public class micros{
    //3-A- Definir una clase para representar micros. Un micro se caracteriza por su patente, destino, hora salida, una cantidad de asientos fija (20) para los que debe registrar su estado (es decir si está o no ocupado) y cantidad de asientos ocupados.  El micro puede ocuparse total o parcialmente.
    //a)Defina métodos getters/setters para patente, destino y hora de salida.
   //b) Implemente un constructor que permita inicializar el micro creado con una patente,  un destino y una hora de salida (recibidas como parámetro) y sin pasajeros. 
   //c)	Implemente métodos para: 

   public void main(String[]args){
       Scanner in = new Scanner(System.in);
       
    }
}