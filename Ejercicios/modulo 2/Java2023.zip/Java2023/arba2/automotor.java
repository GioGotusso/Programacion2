public class automotor extends Vehiculo
{
  //preguntar a dolo pq no me deja que automotor no sea abstracto y que no me toma el calcular impuesto de la clase padre
  //ya que la clase vehiculo comparte un calculo con las sub clases esta debe ser abstracta como la clase figura del power de la clase 5
  private String descripcion;
  private String patente;
  
  public automotor(String unaDescripcion,String unaPatente,int unAño,double impt, Propietario unPropietario){
      super(unAño,impt,unPropietario);
      this.descripcion=unaDescripcion;
      this.patente=unaPatente;
    }
  public String getDescripcion(){
      return descripcion;
  }
  public void setDescripcion(String unaDescripcion){
      descripcion=unaDescripcion;
  }
  public String getPatente(){
      return patente;
  }
  public void setPatente(String unaPatente){
      patente=unaPatente;
  }
  public double calcularImport_adi(){
      double import_adi=0;
      if(getAño()>10){
          import_adi=1000;
      }
      else if(getAño()>5){
          import_adi=500;
      }
      else{
          import_adi=100;
      }
      return import_adi;
  }
  public double calcularImpuesto(){
      double impuesto_tot=0;
      
      impuesto_tot= calcularImport_adi()+super.getImporte();
      
      return impuesto_tot;
  }
}
