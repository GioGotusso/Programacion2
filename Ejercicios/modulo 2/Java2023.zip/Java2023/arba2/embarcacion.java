public class embarcacion extends Vehiculo
{
    private int REY;
    private String nom;
    private String tipo;
    private double eslora;
    private double peso;
    private double imp_dec;
    public embarcacion(int unREY, String unNom, String unTipo,double unaEslora,double unPeso, double unImp_dec,int unAño,double unImporte, Propietario unpropietario){
         super(unAño,unImporte,unpropietario);
         this.REY=unREY;
         this.nom=unNom;
         this.tipo=unTipo;
         this.eslora=unaEslora;
         this.peso=unPeso;
         this.imp_dec=unImp_dec;
    }
    public int getREY(){
        return REY;
    }
    public void setREY(int REY){
        this.REY=REY;
    }
    public String getnom(){
        return nom;
    }
    public void setnom(String nom){
        this.nom=nom;
    }
    public String getTipo(){
        return tipo;
    }
    public void setTipo(String tipo){
        this.tipo=tipo;
    }
    public double getEslora(){
        return eslora;
    }
    public void setEslora(double eslora){
        this.eslora=eslora;
    }
    public double getpeso(){
        return peso;
    }
    public void setpeso(double peso){
        this.peso=peso;
    }
    public double getImp_dec(){
        return imp_dec;
    }
    public void setImp_dec(double imp_dec){
        this.imp_dec=imp_dec;
    }
    public double calcularImpuesto(){
        double monto=0;
        double tot=0;
        if(getImp_dec()<=6000){
            monto=getImp_dec()*0.04;
        }
        else if((getImp_dec()>=6000)&&(getImp_dec()<=180000)){
            monto=getImp_dec()*0.02;
        }
        else {
            monto=getImp_dec()*0.05;
        }
        tot=monto+getImporte();
        return tot;
    }
}
