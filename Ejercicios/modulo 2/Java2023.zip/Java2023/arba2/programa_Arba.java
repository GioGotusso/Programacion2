import java.util.Scanner;
public class programa_Arba
{
    public static void main(String[]args){
        //vector de 5, cargarlo a mano y decir despues digo for i=0,i<5,i++ do System.out.println(v[i].calcularImpuesto());
        //inicialzar variables necesarias
        Scanner in = new Scanner(System.in);
        Vehiculo[]vecV;
        vecV= new Vehiculo[5];
        int x,i;
        //nose si conviene cargar el vector en un modulo ya que luego lo tengo ue pasar al main, lo mismo sucede con el recorrido completo
        //para imprimir el impuesto.
        for(i=0;i<5;i++){
            System.out.println("ingrese 1 para agregar un automotor o ingrese 2 para agregar una embarcacion");
            x=in.nextInt();
            if(x==1){
                //agrego automotor
                vecV[i]=crearAutomotor(in);
            }
            else if(x==2){
                //agrego una embarcacion 
                vecV[i]=crearEmbarcacion(in);
            }
        }
        //recorro el vector de forma completa para imprimir el impuesto
        for(i=0;i<5;i++){
            System.out.println("el impuesto a pagar del vehiculo es de"+vecV[i].calcularImpuesto());
            //es necesario hacer el (i+1)? preguntar a dolo
            //segun yo no ya que es un for, y tambien se carga la posicion 0 en el primer for
        }    
        }
    public static Vehiculo crearAutomotor(Scanner in) {
        System.out.println("ingrese un año");
        int año=in.nextInt();
        System.out.println("ingrese un importe");
        double importe= in.nextDouble();
        System.out.println("ingrese un cit");
        int cit=in.nextInt();
        System.out.println("ingrese un nombre");
        String nom=in.next();
        System.out.println("ingrese un apellido");
        String ape=in.next();
        System.out.println("ingrese una descripcion");
        String desc=in.next();
        System.out.println("ingrese una patente ");
        String patente=in.next();
        Propietario propietario=new Propietario(nom,ape,cit);
        automotor auto=new automotor (desc,patente,año,importe,propietario);
        return auto;
    }
    public static Vehiculo crearEmbarcacion(Scanner in){
        System.out.println("ingrese un año");
        int año=in.nextInt();
        System.out.println("ingrese un importe");
        double importe= in.nextDouble();
        System.out.println("ingrese un cit");
        int cit=in.nextInt();
        System.out.println("ingrese un nombre");
        String nom=in.next();
        System.out.println("ingrese un apellido");
        String ape=in.next();
        System.out.println("ingrese un REY");
        int REY=in.nextInt();
        System.out.println("ingrese un nombre");
        String nomb=in.next();
        System.out.println("ingrese un tipo");
        String tipo=in.next();
        System.out.println("ingrese una eslora");
        double eslora= in.nextDouble();
        System.out.println("ingrese un peso");
        double peso= in.nextDouble();
        System.out.println("ingrese un importe");
        double imp_dec= in.nextDouble();
        Propietario propietario= new Propietario(nom,ape,cit);
        embarcacion barco= new embarcacion(REY,nomb,tipo,eslora,peso,imp_dec,año,importe,propietario);
        return barco;
    }
}   
