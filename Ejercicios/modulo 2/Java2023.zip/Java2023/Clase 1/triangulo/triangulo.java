import java.util.Scanner;
public class triangulo
{
    public static void main(String[] args){
     Scanner in = new Scanner(System.in);// instance variables - replace the example below with your own
      System.out.print("ingrese el primer lado: ");
      double a= in.nextDouble();
      System.out.print("ingrese el segundo lado: ");
      double b = in.nextDouble();
      System.out.print("ingrese el ultimo lado: ");
      double c = in.nextDouble();
      in.close();
      double perimetro = a+b+c;
     
      if((a<b+c)&&(b<a+c)&&(c<b+a)){
           System.out.print("el triangulo es valido y el perimetro es: "+perimetro);
        }
      else {
             System.out.print("el triangulo no es valido");
            }
        }
    }