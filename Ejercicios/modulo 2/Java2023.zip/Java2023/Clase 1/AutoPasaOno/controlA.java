import java.util.Scanner; 
public class controlA {
  public static void main(String[] args)
 { 
    Scanner in = new Scanner(System.in);
    System.out.print("ingrese una patente");
    int patente = in.nextInt();
    int cantV=0;
    int cantP=0;
    while (patente != 0) {
        cantP++;
       if(patente % 2 == 0){
         System.out.print("la patente es valida");
         cantV++;
        }
       else {
           System.out.print("la patente no es valida");
           
        } 
      System.out.print("Ingrese una patente de auto: ");
      patente = in.nextInt();
    }
    in.close();
    double porcentaje = cantV*100/cantP;
    System.out.print("el porcentaje de autos que pasaron es: "+porcentaje);
   }
}