import java.util.Scanner; 
public class basket
{

    public static void main(String[] args)
    {
        //Paso 1: Declarar la variable vector de alturas
        //Paso 2: Declarar indice y promedio (iniciarlo)
        int i ;
        int j;
        int cant=0;
        double prom = 0;
        //Paso 3: Declarar y crear el scanner
      Scanner in = new Scanner(System.in);      
        //Paso 4: Crear el vector para 15 valores
        double Alturas[]=new double[15];
        //Paso 5: Ingresar 15 numeros, cargarlos en el vector, ir calculando la suma
        for(i=0;i<15;i++){
            System.out.print("ingrese una altura");
            Alturas[i]=in.nextDouble();
            prom=prom+Alturas[i];
        }
        //Paso 6: Calcular el promedio
        prom= prom/15;
        //Paso 7: Recorrer el vector, contar los números que son mayores que el promedio
         for(j=0;j<15;j++){
            if(Alturas[j]>prom){
                cant++;    
            } 
        }
        System.out.print("la altura promedio es: "+prom);
        System.out.print("la cantidad de jugadores por encima del promdio son: "+cant);
      in.close();
   }
   }
    //}
//}
