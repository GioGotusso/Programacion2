import java.util.Scanner;
public class Ejercicio2
{
    public static void main(String [] args){
      Scanner in = new Scanner(System.in);
      System.out.println("Ingrese el nombre del entrenador: ");
      String nom = in.next();
      System.out.println("Ingrese el sueldo del entrenador: ");
      double sueldo = in.nextDouble();
      System.out.println("Ingrese el sueldo del entrenador: ");
      int camGan = in.nextInt();
      in.close();
      Entrenador ent = new Entrenador(nom,sueldo,camGan);
      System.out.println(ent.calcularSueldoACobrar());
    }
}
