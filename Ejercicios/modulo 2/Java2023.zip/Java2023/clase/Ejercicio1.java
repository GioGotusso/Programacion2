import java.util.Scanner;
public class Ejercicio1
{
  
  
    public static void main(String [] args)
    {    Scanner in = new Scanner(System.in);      
         System.out.println("Ingrese un lado 1: ");
         double lado1 = in.nextDouble();
         System.out.println("Ingrese un lado 2: ");
         double lado2 = in.nextDouble();
         System.out.println("Ingrese un lado 3: ");
         double lado3 = in.nextDouble();
         System.out.println("Ingrese un color ṕara las lineas: ");
         String colorL = in.next();
         System.out.println("Ingrese un color ṕara el relleno: ");
         String colorR = in.next();
         in.close();
         Triangulo tri = new Triangulo(lado1,lado2,lado2,colorL,colorR);
         System.out.println("El area de triangulo es "+ tri.calcularArea());
         System.out.println("El perimetro de triangulo es "+ tri.calcularPerimetro());
         System.out.println(tri.toString());
    }

}
