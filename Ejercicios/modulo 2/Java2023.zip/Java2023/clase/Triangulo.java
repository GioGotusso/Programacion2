

public class Triangulo
{

    private double lado1;
    private double lado2;
    private double lado3;
    private String colorL;
    private String colorR;
     public Triangulo(double lado1,double lado2,double lado3,String colorL,String colorR)
    {
       this.lado1=lado1;
       this.lado2=lado2;
       this.lado3=lado3;
       this.colorL=colorL;
       this.colorR=colorR;
    }
    public Triangulo()
    {
       
    }

    public void setLado1(double lado1)
    {
        this.lado1=lado1;
    }
    public void setLado2(double lado2)
    {
        this.lado2=lado2;
    }
    public void setLado3(double lado3)
    {
        this.lado3=lado3;
    }
    public void setColorL(String colorL){
        this.colorL=colorL;
    }
    public void setColorR(String colorR){
        this.colorR=colorR;
    }
    public double getLado1(){
       return this.lado1;
    }
    public double getLado2(){
       return this.lado2;
    }
    public double getLado3(){
       return this.lado3;
    }
    public String getcolorL(){
       return this.colorL;
    }
    public String getcolorR(){
       return this.colorR;
    }
    public double calcularPerimetro(){
       double perimetro;
       perimetro = this.lado1 + this.lado2 + this.lado3;
       return perimetro;
    }
    public double calcularArea(){
      double area,s;
      s = (this.lado1 + this.lado2 + this.lado3)/2;
      area =Math.sqrt(s*(s-this.lado1)*(s-this.lado2)*(s-this.lado3));
      return area;
      }
    public String toString (){
        String aux;
        aux = "Es un triangulo con un su lados "+ this.lado1 + this.lado2 + this.lado3 +" y con un color de lineas "+ this.colorL + " y con un color de relleno " + this.colorR;
        return aux;
    }
}



