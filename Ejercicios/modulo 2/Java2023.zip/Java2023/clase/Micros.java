
public class Micros
{
    private String patente;
    private String destino;
    private String horaSalida;
    private boolean [] vector;
    private int cantOcup;
    public Micros(String patente,String destino,String horaSalida)
    {
       this.patente=patente;
       this.destino=destino;
       this.horaSalida=horaSalida;
       vector = new boolean [20];
       for(int i=0;i<20;i++){
          this.vector[i]=false;
        }
    }
    public Micros()
    {
       
    }
    public void setPatente(String patente){
       this.patente=patente;
    }
    public void setDestino(String destino){
       this.destino=destino;
    }
    public void setHoraSalida(String horaSalida){
      this.horaSalida=horaSalida;
    }
    public String getPatente(){
       return this.patente;
    }
    public String getDestino(){
      return this.destino;
    }
    public String getHoraSalida(){
      return this.horaSalida;
    }
    public int cantidaOcupados(){
       int cant = 0;
       for(int i =0;i<20;i++){
          if(this.vector[i]){
             cant++;
            }
        }
       return cant;
    }
}
