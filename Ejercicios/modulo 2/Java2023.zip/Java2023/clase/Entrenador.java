

public class Entrenador
{
    private String nombre;
    private double sueldo;
    private int campGan;
    public Entrenador(String nombre,double sueldo,int campGan)
    {
        this.nombre=nombre;
        this.sueldo=sueldo;
        this.campGan = campGan;
    }
    public Entrenador()
    {
    }
    public void setNombre(String nombre)
    {
        this.nombre=nombre;
    }
    public void setSueldo(double sueldo)
    {
        this.sueldo=sueldo;
    }
    public void setCampGan(int campGan)
    {
        this.campGan = campGan;
    }
    public String getNombre(){
      return this.nombre;
    }
    public double getSueldo(){
      return this.sueldo;
    }
    public int getCampGan(){
      return this.campGan;
    }
    public double calcularSueldoACobrar (){
      double sueldoReal;
      sueldoReal = this.sueldo;
      if((campGan>0)&&(campGan<5)){
          sueldoReal = sueldoReal + 5000;
        }
      else{
          if((campGan>4)&&(campGan<10)){
            sueldoReal = sueldoReal + 30000;
            }
           if(campGan>10){
              sueldoReal = sueldoReal + 50000;
            }         
        }
      return sueldoReal;
    }
}
