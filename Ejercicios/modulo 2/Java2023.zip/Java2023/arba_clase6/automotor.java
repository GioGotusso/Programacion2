public class automotor extends Vehiculo{
    private int patente;
    private double monto_adi;
    private String descripcion;
    
     public automotor(int unPatente,double unMonto,String unaDescripcion, int unCit,String unNombre,String unape ){
      super(unCit,unNombre,unape);
      patente=unPatente;
      monto_adi=unMonto;
      descripcion=unaDescripcion;
    }
    public int getPatente(){
        return patente;
    }
    public double getMonto(){
        return monto_adi;
    }
    public String getDescripcion(){
        return descripcion;
    }