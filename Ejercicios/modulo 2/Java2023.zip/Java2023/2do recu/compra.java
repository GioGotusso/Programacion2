public abstract class compra
{
    // instance variables - replace the example below with your own
    private int num_C;
    private int categoria;
    private String nom_E;
    private String Fecha;
    private double importe;
    public compra(){}
    public compra(int num_C,int categoria,String nom_E,String fecha,double importe){
        this.num_C=num_C;
        this.categoria=categoria;
        this.nom_E=nom_E;
        this.Fecha=fecha;
        this.importe=importe;
    }
    public int getnum_C(){
    return num_C;
    }
    public void setnum_C(int num_C){
    this.num_C= num_C;
    }
    public int getcategoria(){
    return categoria;
    }
    public void setcategoria(int categoria){
    this.categoria= categoria;
    }
    public String getnom_E(){
    return nom_E;
    }
    public void setnom_E(String nom_E){
    this.nom_E= nom_E;
    }
    public String getFecha(){
    return Fecha;
    }
    public void setFecha(String Fecha){
    this.Fecha= Fecha;
    }
    public double getimporte(){
    return importe;
    }
    public void setimporte(double importe){
    this.importe= importe;
    }
    abstract void descuento();
}
