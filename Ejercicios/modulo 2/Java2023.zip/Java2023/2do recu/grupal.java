public class grupal extends compra
{
    private int[]DNIS;
    private int diml=0;
    public grupal(){}
    public grupal(int numero_R,String Aeropuerto_S,String AeropuertoD,String Fecha,double Importe,double Precio){
        super(numero_R,Aeropuerto_S,AeropuertoD,Fecha,Importe,Precio);
        DNIS= new int[30];
    }
    public void cargarVec(int Dni){
        DNIS[diml]=Dni;
        diml++;
    }
    public void calcularTot(double precio){
        double Total;
        Total= precio*diml;
        super.setImporte(Total);
    }
    public void descuento(){
        double m=super.getPrecio();
        int aux=diml;
        if(diml<6){
            m-=super.getPrecio()*0.05;
            super.setImporte(m);
            }
        // m-=(diml/10)*precio
        while(aux>=10){
          m=m-super.getPrecio();
          aux-=10;
        }   
        super.setImporte(m);
    }
    public String toString(){
        String aux;
        aux= super.toString();
        for(int i=0;i<diml;i++){
            aux+= "los dnis del grupo son: "+DNIS[i];
        }
        return aux;  
     }
    }
