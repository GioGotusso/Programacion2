
public class simple extends compra
{
    // instance variables - replace the example below with your own
    private int Dni;
    private String nombre;
    private String ape;
    private String num_a;
     public int getDni(){
    return Dni;
    }
    public void setDni(int Dni){
    this.Dni= Dni;
    }
    public String getnombre(){
    return nombre;
    }
    public void setnombre(String nombre){
    this.nombre= nombre;
    }
    public String getape(){
    return ape;
    }
    public void setape(String ape){
    this.ape= ape;
    }
    public String getnum_a(){
    return num_a;
    }
    public void setnum_a(String num_a){
    this.num_a= num_a;
    }
    public void descuento(){
        double m=super.getimporte();
        if((super.getnom_E().toLowerCase().equals("lusail"))&&(super.getcategoria()==4)){
            m-=super.getimporte()*0.1;
            super.setimporte(m); 
        }
    }
}
