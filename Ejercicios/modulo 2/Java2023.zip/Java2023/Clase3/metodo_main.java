import java.util.Scanner;
public class metodo_main
{
    /**
     * Constructor for objects of class metodo_main
     */
    public static void main(String[]args)
    {
        Scanner in = new Scanner(System.in);
        System.out.println("ingrese el lado 1");
        double Lado1 = in.nextDouble();
        System.out.println("ingrese el lado 2");
        double Lado2 = in.nextDouble();
        System.out.println("ingrese el lado 3");
        double Lado3 = in.nextDouble();
        System.out.println("ingrese un color de relleno");
        String Color = in.next();
        System.out.println("ingrese el color de la linea");
        String Linea = in.next();
        triangulo t = new triangulo(Lado1,Lado2,Lado3,Color,Linea);
        System.out.println();
        System.out.println("el primer lado es: "+t.getLado1());
        System.out.println("el segundo lado es: "+t.getLado2());
        System.out.println("el tercer lado es: "+t.getLado3());
        System.out.println("el color de relleno es: "+t.getColor());
        System.out.println("el color de la linea: "+t.getLinea());
        System.out.println();
        System.out.println("el area del triangulo es: "+t.calcularArea());
        System.out.println("el perimetro del triangulo es: "+t.calcularPerimetro());
        in.close();
    }
}
