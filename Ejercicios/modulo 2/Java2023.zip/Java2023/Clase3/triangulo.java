public class triangulo{
    private double lado1;
    private double lado2;
    private double lado3;
    private String color;
    private String linea;
    
    public triangulo(double unLado1, double unLado2, double unLado3, String unColorR,String unColorL){
        setLado1(unLado1);
        setLado2(unLado2);
        setLado3(unLado3);
        setColor(unColorR);
        setLinea(unColorL);
    }
    
    
    public double getLado1(){
        return lado1;
    }
    public double getLado2(){
        return lado2;
    }
    public double getLado3(){
        return lado3;
    }
    public String getColor(){
        return color;
    }
    public String getLinea(){
        return linea;
    }
    public void setColor(String unColor){
        color=unColor;
    }
    public void setLinea(String unaLinea){
        linea=unaLinea;
    }
    public void setLado1(double unLado1){
        lado1=unLado1;
    }
    public void setLado2(double unLado2){
        lado2=unLado2;
    }
    public void setLado3(double unLado3){
        lado3=unLado3;
    }
    public String toString(){
	return ("el lado 1 es"+ lado1 + " el lado 2 es " + lado2 + " lado 3 es " + lado3 + " el color del triangulo es " + color + "el color de la linea es"+linea );
    }
    private double calcularS (){
        return (lado1+lado2+lado3)/2;
    }
    public double calcularArea(){
        double s=calcularS();
        return (Math.sqrt(s*(s-lado1)*(s-lado2)*(s-lado3)));
    }
    
    public double calcularPerimetro(){
        return (lado1+lado2+lado3);
    }
}