public class clasica extends reserva
{
    private int Dni;
    private String num_A;
    public clasica(){}
    public clasica(int Dni,String num_A,int numero_R,String Aeropuerto_S,String AeropuertoD,String Fecha,double Importe,double Precio){
        super(numero_R,Aeropuerto_S,AeropuertoD,Fecha,Importe,Precio);
        this.Dni=Dni;
        this.num_A=num_A;
    }
     public int getDni(){
    return Dni;
    }
    public void setDni(int Dni){
    this.Dni= Dni;
    }
    public String getnum_A(){
    return num_A;
    }
    public void setnum_A(String num_A){
    this.num_A= num_A;
    }
    public void descuento(){
        double total;
        total=super.getPrecio();
        total-=super.getPrecio()*0.1;
        super.setImporte(total);
    }
    public String toString(){
        String aux;
        aux= super.toString()+"el dni es"+Dni+"el numero de asiento es"+num_A;
        return aux;
    }
}
