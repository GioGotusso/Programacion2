public abstract class reserva
{
    private int numero_R;
    private String Aeropuerto_S;
    private String AeropuertoD;
    private String Fecha;
    private double Importe;
    private double Precio;
    public reserva(){
    }
    public reserva(int numero_R,String Aeropuerto_S,String AeropuertoD,String Fecha,double Importe,double Precio){
        this.numero_R=numero_R;
        this.Aeropuerto_S=Aeropuerto_S;
        this.AeropuertoD=AeropuertoD;
        this.Fecha=Fecha;
        this.Importe=Importe;
        this.Precio=Precio;
    }
    public int getnumero_R(){
    return numero_R;
    }
    public void setnumero_R(int numero_R){
    this.numero_R= numero_R;
    }
    public String getAeropuerto_S(){
    return Aeropuerto_S;
    }
    public void setAeropuerto_S(String Aeropuerto_S){
    this.Aeropuerto_S= Aeropuerto_S;
    }
    public String getAeropuertoD(){
    return AeropuertoD;
    }
    public void setAeropuertoD(String AeropuertoD){
    this.AeropuertoD= AeropuertoD;
    }
    public String getFecha(){
    return Fecha;
    }
    public void setFecha(String Fecha){
    this.Fecha= Fecha;
    }
    public double getImporte(){
    return Importe;
    }
    public void setImporte(double Importe){
    this.Importe= Importe;
    }
    public double getPrecio(){
    return Precio;
    }
    public void setPrecio(double Precio){
    this.Precio= Precio;
    }
    abstract void descuento();
    public String toString(){
        String aux;
        aux= "el numero de reserva es"+numero_R+"el aeropuerto de salida es"+Aeropuerto_S+"el destino es"+AeropuertoD+"la fecha es"+Fecha+"el precio es"+Precio+"el importe es"+Importe;
        return aux;
    }
}
