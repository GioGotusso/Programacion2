import java.util.Scanner;
public class main
{
    public static void main(){
        Scanner in = new Scanner(System.in);
        reserva[]vec;
        int x;
        vec= new reserva[3];
        for(int i=0;i<3;i++){
            System.out.println("ingrese 1 para una reserva clasica o ingrese 2 para una reserva grupal");
            x=in.nextInt();
            if(x==1){
               vec[i]=leerClasica(in);
            }
            else{
               vec[i]=leerGrupal(in);
            }
        }  
        for(int i=0;i<3;i++){
            vec[i].descuento();
            System.out.println(vec[i].toString());
        }
        in.close();
        }
    public static reserva leerClasica(Scanner in){
        System.out.println("numero de reserva");
        int num= in.nextInt();
        System.out.println("Aeropuerto de origen");
        String AeropuertoS= in.next();
        System.out.println("Aeropuerto Destino");
        String AeroD=in.next();
        System.out.println("fecha");
        String fecha=in.next();
        System.out.println("importe");
        double imp=in.nextDouble();
        System.out.println("precio");
        double precio=in.nextDouble();
        System.out.println("num de asiento");
        String num_A=in.next();
        System.out.println("dni");
        int dni=in.nextInt();
        clasica c = new clasica(dni,num_A,num,AeropuertoS,AeroD,fecha,imp,precio);
        return c;
    }
    public static reserva leerGrupal(Scanner in){
        System.out.println("numero de reserva");
        int num= in.nextInt();
        System.out.println("Aeropuerto de origen");
        String AeropuertoS= in.next();
        System.out.println("Aeropuerto Destino");
        String AeroD=in.next();
        System.out.println("fecha");
        String fecha=in.next();
        System.out.println("importe");
        double imp=in.nextDouble();
        System.out.println("precio");
        double precio=in.nextDouble();
        grupal g = new grupal(num,AeropuertoS,AeroD,fecha,imp,precio);
        System.out.println("ingrese numero de personas en la reserva");
        int cant= in.nextInt();
        for(int i=0;i<cant;i++){
         System.out.println("ingrese dni");
         int DNI=in.nextInt();
         g.cargarVec(DNI);
        }
        g.calcularTot(precio);
        return g;
    }
    }
