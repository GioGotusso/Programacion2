public abstract class solicitud
{
    private String num_g;
    private String fecha;
    private double IMD;
    private int cant_i;
    private String region;
    private persona persona;
    public solicitud(String num_g, String fecha, double IMD, int cant_i, String region, persona persona) {
        this.num_g=num_g;
        this.fecha=fecha;
        this.IMD=IMD;
        this.cant_i=cant_i;
        this.region=region;
        this.persona=persona;
    }
    solicitud(){
        
    }
    public String getnum_g(){
    return num_g;
    }
    public void setnum_g(String num_g){
    this.num_g= num_g;
    }
    public String getfecha(){
    return fecha;
    }
    public void setfecha(String fecha){
    this.fecha= fecha;
    }
    public double getIMD(){
    return IMD;
    }
    public void setIMD(double IMD){
    this.IMD= IMD;
    }
    public int getcant_i(){
    return cant_i;
    }
    public void setcant_i(int cant_i){
    this.cant_i= cant_i;
    }
    public String getregion(){
    return region;
    }
    public void setregion(String region){
    this.region= region;
    }
    public persona getPersona() {
        return persona;
    }
    public void setPersona(persona persona) {
        this.persona=persona;
    }
    
    abstract double calcularGasto();
    abstract boolean calcularAccede();
    public String toSstring(){
       String aux;
       aux="numero de gestion: "+num_g+"fecha de solicitud: "+fecha+"ingresos mensuales"+IMD+"cantidad de ingrantes"+cant_i+"region"+region+"nombre del solicitante: "+persona.getnombre()+"apellido"+persona.getapellido()+"cuit"+persona.getcuit();
       return aux;
    }
}
