
public class persona
{
    private String nombre;
    private String apellido;
    private int cuit;
    public persona(String nombre,String apellido,int cuit){
        this.nombre=nombre;
        this.apellido=apellido;
        this.cuit=cuit;
    }
    persona(){
    }
    public String getnombre(){
    return nombre;
    }
    public void setnombre(String nombre){
    this.nombre= nombre;
    }
    public String getapellido(){
    return apellido;
    }
    public void setapellido(String apellido){
    this.apellido= apellido;
    }
    public int getcuit(){
    return cuit;
    }
    public void setcuit(int cuit){
    this.cuit= cuit;
    }
}
