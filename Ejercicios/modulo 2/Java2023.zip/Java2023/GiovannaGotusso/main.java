import java.util.Scanner;
public class main
{
    public static void main(String[]args){
        Scanner in = new Scanner(System.in); 
        libro[]vecL;
        vecL= new libro[5];
        int i,x;
        double precioF=0;
        for(i=0;i<5;i++){
            System.out.println("ingrese 1 para agregar un libro de literatura o ingrese 2 para agregar un libro divulgativo");
            x=in.nextInt();
            if(x==1){
                vecL[i]=agregarLibroL(in);
            }
            else if(x==2)
                vecL[i]=agregarLibroD(in);
        }
        for(i=0;i<5;i++){
            precioF=vecL[i].montoTot();
            vecL[i].setprecio(precioF);
            vecL[i].tosstring();
            
        }
    }
    public static libro agregarLibroL(Scanner in){
          System.out.println("ingrese un nombre de editorial");
        String nombre=in.next();
        System.out.println("ingrese una cantidad de premios ");
        int cant_P= in.nextInt();
        System.out.println("ingrese un Dni");
        int dni=in.nextInt();
        System.out.println("ingrese un nombre");
        String nom=in.next();
        System.out.println("ingrese un apellido");
        String ape=in.next();
        System.out.println("ingrese una nacionalidad");
        String nacio=in.next();
        System.out.println("ingrese un ISBN ");
        String ISBN=in.next();
        System.out.println("ingrese un nombre");
        String nomb=in.next();
        System.out.println("ingrese una cantidad de pag");
        int cant_pag=in.nextInt();
        System.out.println("ingrese un precio");
        double precio=in.nextDouble();
        System.out.println("ingrese una fecha");
        String fecha=in.next();
        System.out.println("ingrese un tipo genero");
        String tipo=in.next();
        System.out.println("ingrese si es edicion de bolsillo o no");
        boolean edicion=in.nextBoolean();
        autor autor=new autor(dni,nom,ape,nacio);
        literatura lit=new literatura (tipo,edicion,ISBN,nomb,cant_pag,precio,fecha,autor,nombre,cant_P);
        return lit;
    }
    public static libro agregarLibroD(Scanner in){
        System.out.println("ingrese un nombre de editorial");
        String nombre=in.next();
        System.out.println("ingrese una cantidad de premios ");
        int cant_P= in.nextInt();
        System.out.println("ingrese un Dni");
        int dni=in.nextInt();
        System.out.println("ingrese un nombre");
        String nom=in.next();
        System.out.println("ingrese un apellido");
        String ape=in.next();
        System.out.println("ingrese una nacionalidad");
        String nacio=in.next();
        System.out.println("ingrese un ISBN ");
        String ISBN=in.next();
        System.out.println("ingrese un nombre");
        String nomb=in.next();
        System.out.println("ingrese una cantidad de pag");
        int cant_pag=in.nextInt();
        System.out.println("ingrese un precio");
        double precio=in.nextDouble();
        System.out.println("ingrese una fecha");
        String fecha=in.next();
        System.out.println("ingrese un tipo genero");
        String tipo=in.next();
        autor autor= new autor(dni,nom,ape,nacio);
        divulgativo dil=new divulgativo(tipo,nom,cant_P,ISBN,nomb,cant_pag,precio,fecha,autor);
        return dil;
    }
    }

