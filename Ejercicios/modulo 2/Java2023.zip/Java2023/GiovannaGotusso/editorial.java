public abstract class editorial
{
    // instance variables - replace the example below with your own
    private String nombre;
    private int cant_P;
    public editorial(String nombre, int cant_P)
    {
        this.nombre=nombre;
        this.cant_P=cant_P;
    }
    editorial(){
    }
    public String getnombre(){
    return nombre;
    }
    public void setnombre(String nombre){
    this.nombre= nombre;
    }
    public int getcant_P(){
    return cant_P;
    }
    public void setcant_P(int cant_P){
    this.cant_P= cant_P;
    }
    public String toString(){
        String aux;
        aux="el nombre de la editorial es: "+nombre+"la cantidad de premios ganados es: "+cant_P;
        return aux;
    }
    abstract double montoTot();
    }
