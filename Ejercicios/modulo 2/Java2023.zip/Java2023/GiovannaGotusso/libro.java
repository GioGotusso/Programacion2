
/**
 * Write a description of class padre here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class libro extends editorial 
{
    // instance variables - replace the example below with your own
    private String ISBN;
    private String nombre;
    private int cant_pag;
    private double precio;
    private String fecha;
    private autor autor;
    
    public libro(String ISBN,String nombre,int cant_pag,double precio,String fecha, autor autor,String nom,int cant_P){
        super(nom,cant_P);
        this.ISBN=ISBN;
        this.nombre=nombre;
        this.cant_pag=cant_pag;
        this.precio=precio;
        this.fecha=fecha;
        this.autor=autor;
    }
    
    
     public String getISBN(){
    return ISBN;
    }
    public void setISBN(String ISBN){
    this.ISBN= ISBN;
    }
    public String getnombre(){
    return nombre;
    }
    public void setnombre(String nombre){
    this.nombre= nombre;
    }
    public int getcant_pag(){
    return cant_pag;
    }
    public void setcant_pag(int cant_pag){
    this.cant_pag= cant_pag;
    }
    public double getprecio(){
    return precio;
    }
    public void setprecio(double precio){
    this.precio= precio;
    }
    public String getfecha(){
    return fecha;
    }
    public void setfecha(String fecha){
    this.fecha= fecha;
    }
    public autor getAutor(){
        return autor;
    }
    public void setAutor(autor autor){
        this.autor=autor;
    }
    public String tosstring(){
        String aux;
        aux= super.toString()+"el ISBN es"+ISBN+"el nombre del libro es"+nombre+"la cantidad de paginas es"+cant_pag+"el precio es"+precio+"la fecha de publicacion es"+fecha+"el nombre del autor es"+getAutor().getNombre()+"el apellido es"+getAutor().getNombre()+"el dni del autor es"+getAutor().getDni()+"la nacionalidad del autor es"+getAutor().getNacionalidad();
        return aux;
    }
    abstract double montoTot();
}
