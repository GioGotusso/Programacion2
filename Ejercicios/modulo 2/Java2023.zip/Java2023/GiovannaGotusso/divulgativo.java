public class divulgativo extends libro
{
    // instance variables - replace the example below with your own
    private String tipo;

    public divulgativo(String tipo,String nomb,int Cant_P,String ISBN,String nombre,int cant_pag,double precio,String fecha,autor autor){
        super(ISBN,nombre,cant_pag,precio,fecha,autor,nomb,Cant_P);
        this.tipo=tipo;
    }
    public String getTipo(){
        return tipo;
    }
    public void setTipo(String tipo){
        this.tipo=tipo;
    }
    public double montoTot(){
        double precioF2=0;
        if((super.getfecha().compareTo("15/03/2020")>0)||(super.getfecha().compareTo("15/12/2022")<0)){
            precioF2= super.getprecio()-super.getprecio()*0.0605;
        }
        if((tipo=="divulgacion cientifica")&&(super.getAutor().getNacionalidad()=="argentino")){
            precioF2= super.getprecio()-super.getprecio()*0.10; 
        }
        return precioF2;
    }
    public String tosstring(){
        String aux;
        aux=super.tosstring()+"el genero es"+tipo;
        return aux;
    }
}
