
public class literatura extends libro
{
    private String tipo;
    private boolean edicion;
    public literatura(String tipo, boolean edicion,String ISBN,String nombre,int cant_pag,double precio,String fecha,autor autor,String nom,int cant_P){
        super(ISBN,nombre,cant_pag,precio,fecha,autor,nom,cant_P);
        this.tipo=tipo;
        this.edicion=edicion;
    }
     public String gettipo(){
    return tipo;
    }
    public void settipo(String tipo){
    this.tipo= tipo;
    }
    public boolean getedicion(){
    return edicion;
    }
    public void setedicion(boolean edicion){
    this.edicion= edicion;
    }
    public double montoTot(){
        double precioF=0;
        if(edicion){
            precioF= super.getprecio()-super.getprecio()*0.15;
        }
        if(tipo=="cuento"){
            precioF=super.getprecio()-super.getprecio()*0.05;
        }
        else if (tipo=="novela"){
            precioF=super.getprecio()-super.getprecio()*0.05;
        }
        return precioF;
    }
    public String tosstring(){
        String aux;
        aux=super.tosstring()+"el genero es"+tipo+"es edicion de bolsillo"+edicion;
        return aux;
    }
}

