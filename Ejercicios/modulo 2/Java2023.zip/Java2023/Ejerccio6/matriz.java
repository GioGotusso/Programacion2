import java.util.Scanner;
public class matriz
{ 
    public static void main(String[] args)
    {
        Scanner in= new Scanner(System.in);   
        int [][] Matriz;
           final int fila=10;
           final int col=10;
           Matriz= new int[fila][col];
           int f;
           int c;
           int cantP=0;
        for(f=0;f<fila;f++){
            for(c=0;c<col;c++){
             Matriz[f][c]=cantP;
             cantP= cantP + 2;
             }
        }
        for(f=0;f<fila;f++){
            for(c=0;c<col;c++){
             System.out.println(Matriz[f][c]);
             }
        }
        int suma=0;
        for(f=2;f<=9;f++){
            for(c=0;c<=3;c++){
             suma = suma + Matriz[f][c];
             }
        }