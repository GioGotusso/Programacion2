import java.util.Scanner;
public class programaPPL
{
    public static void main(String[]args){
        Scanner in= new Scanner(System.in);
        Persona per= new Persona();
        System.out.println("Escriba un nombre");
        String nom = in.next();
        per.setNombre(nom);
        System.out.println("Escriba un dni");
        int dni = in.nextInt();
        per.setDNI(dni);
        System.out.println("Ingrese una edad");
        int ed = in.nextInt();
        per.setEdad(ed);
        System.out.println(per.toString());
        
        Persona[]vec;
        vec = new Persona[4];
        
        int i;
        for(i=0;i<4;i++){
            per= new Persona();
            System.out.println("Escriba un nombre");
            nom = in.next();
            per.setNombre(nom);
            System.out.println("Escriba un dni");
            dni = in.nextInt();
            per.setDNI(dni);
            System.out.println("Ingrese una edad");
            ed = in.nextInt();
            per.setEdad(ed);
            vec[i]=per;
            
        }
        System.out.println("la cantidad de personas mayores a 65 años son: "+mayores65(vec));
        System.out.println(min(vec));
        in.close();
    }
    public static int mayores65(Persona[] vec){
       int cant=0;
         for(int i=0;i<4;i++){
           if(vec[i].getEdad()>65) {  
                cant++;
            }
       }
       return cant;
    }
    public static String min(Persona[]vec){
        int min=99999999;
        int pos=0;
        for(int i=0;i<4;i++){
           if(vec[i].getDNI()<min) {  
                pos= i;
                min= vec[i].getDNI();
            }
        }
        return vec[pos].toString();
    }
}