public abstract class empleado
{
    // instance variables - replace the example below with your own
    private int Dni;
    private String nombre;
    private int edad;
    private double Sueldo;
    public empleado(String nom, int ed,int dni,double sueldo){
        this.setNombre(nom);
        this.setEdad(ed);
        this.setDNI(dni);
        this.setSueldo(sueldo);
    }
    public empleado(){
    }
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nom){
        this.nombre=nom;
    }
    public void setEdad(int ed){
        this.edad=ed;
    }
    public int getEdad(){
        return edad;
    }
    public void setDNI(int dni){
        this.Dni=dni;
    }
    public int getDni(){
        return Dni;
    }
    public void setSueldo(double sueldo){
        this.Sueldo=sueldo;
    }
    
    public double getSueldo(){
        return Sueldo;
    }
    abstract double calcularSueldo();
}  
