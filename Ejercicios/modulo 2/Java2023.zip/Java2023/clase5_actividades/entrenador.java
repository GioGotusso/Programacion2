
public class entrenador extends empleado
{
  private int campeonatos;
    public entrenador(int cantC, int unDni,int unaedad, double unSueldo,String unNombre){
      super(unNombre,unaedad,unDni,unSueldo);
      campeonatos=cantC;
  } 
  public entrenador(){

    }
  public int getCampeonatos(){
      return campeonatos;
    }
  public void setCampeonatos(int cantC){
      this.campeonatos=cantC;
    }
  public void calcularSueldo(){
    }
}
