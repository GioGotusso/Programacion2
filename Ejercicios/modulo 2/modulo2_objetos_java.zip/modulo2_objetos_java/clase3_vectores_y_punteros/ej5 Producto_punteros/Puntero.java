public class Puntero {
    private int DimL;

    public Puntero(int unaDimL){
        DimL=unaDimL;
    }

    public Puntero(){

    }
    public int getDimL() {
        return DimL;
    }
    public void setDimL(int unaDimL) {
        DimL=unaDimL;
    }
}