        System.out.println("El sueldo del entrandor con los campeonatos ganados es de: "+(entrenador.calcularSueldoACobrar()));
